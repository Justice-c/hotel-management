﻿Imports System.Data.OleDb
Public Class checkIn
    Dim guestID, roomID, trans_ID As Integer
    Private Sub checkIn_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call clear_text()
        Dim time As DateTime = DateTime.Now
        Dim format As String = "d/MM/yyyy"
        txtCheckInDate.Text = time.ToString(format)
        dtCheckOutDate.Text = Now.AddDays(1D)
        Call transID()
        Call pop_discount()
    End Sub
    Private Sub checkIn()
        Dim children As Integer = Val(txtChildren.Text)
        Dim adult As Integer = Val(txtAdults.Text)
        Dim advance As Integer = Val(txtAdvance.Text)
        Dim discount As Integer = Val(lblDiscountID.Text)
        Dim reserve As String = "0"
        Dim remarks As String = "Checkin"
        Dim stat As String = "Active"

        If lbl_GuestID.Text = "GuestID" Or lbl_GuestID.Text = Nothing Or txtRoomNumber.Text = Nothing Or Val(children + adult) = Nothing Or advance = Nothing Or discount = Nothing Then
            Call MessageBox.Show("Please Fill All Required Fields", "Notification", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        Else
            If Val(Val(txtSubTotal.Text) * 0.5) > Val(txtAdvance.Text) Then
                Call MessageBox.Show("The Transaction Amount Is Less Than Minimum Amount Defined For This Service", "Notification", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Exit Sub
            End If
            Dim a As String = MessageBox.Show("Confirm Checkin Transaction", "Notification", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
            If a = vbYes Then
                Call con.Close()
                Call con.Open()
                Dim checkin As New OleDbCommand("INSERT INTO tblTransaction(GuestID,RoomNum,CheckInDate,CheckOutDate,NoOfChild,NoOfAdult,AdvancePayment,DiscountID,Remarks,Status) values ('" &
                                                lbl_GuestID.Text & "','" &
                                                txtRoomNumber.Text & "','" &
                                                txtCheckInDate.Text & "','" &
                                                dtCheckOutDate.Text & "','" &
                                                txtChildren.Text & "','" &
                                                txtAdults.Text & "','" &
                                                txtAdvance.Text & "','" &
                                                lblDiscountID.Text & "','" &
                                                remarks & "','" &
                                                stat & "')", con)
                Call checkin.ExecuteNonQuery()

                Dim update_guest As New OleDbCommand("UPDATE tblGuest SET Remarks = 'Checkin' WHERE ID = " & lbl_GuestID.Text & "", con)
                Call update_guest.ExecuteNonQuery()

                Dim update_room As New OleDbCommand("UPDATE tblRoom SET Status = 'Occupied' WHERE RoomNumber = " & txtRoomNumber.Text & "", con)
                Call update_room.ExecuteNonQuery()

                If Val(txtSubTotal.Text) < Val(txtAdvance.Text) Or Val(txtSubTotal.Text) = Val(txtAdvance.Text) Then
                    Call MessageBox.Show("Guest Successfully Checkin " & "Change: $ " & Val(Val(txtAdvance.Text) - Val(txtSubTotal.Text)).ToString("00.00"), "Notification", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    Dim change As String = MessageBox.Show("Return change to customer", "Notification", MessageBoxButtons.OK, MessageBoxIcon.Question)
                    If change = vbYes Then
                        Dim update_trans As New OleDbCommand("UPDATE tblTransaction SET AdvancePayment = " & Val(txtSubTotal.Text) & " WHERE TransID = " & trans_ID & "", con)
                        Call update_trans.ExecuteNonQuery()
                    End If
                Else
                    MessageBox.Show("Guest Successfully Checkin", "Notification", MessageBoxButtons.YesNo, MessageBoxIcon.Information)
                End If

                Call clear_text()
                Call con.Close()
                Call transID()
            End If
        End If
    End Sub
    Public Sub transID()
        Call con.Close()
        Call con.Open()
        Dim dt As New DataTable("tblTransaction")
        rs = New OleDbDataAdapter("SELECT * FROM tblTransaction ORDER BY TransID DESC", con)
        Call rs.Fill(dt)

        If dt.Rows.Count = 0 Then
            txtTransID.Text = "TransID - 0001"
        Else
            Dim value As Integer = Val(dt.Rows(0).Item("TransID"))
            value = value + 1
            txtTransID.Text = value.ToString("0000")
            trans_ID = value
        End If
        Call rs.Dispose()
        Call con.Close()
    End Sub


    Private Sub clear_text()
        txtGuestName.Text = Nothing
        txtRoomNumber.Text = Nothing
        txtRoomType.Text = Nothing
        txtRoomRate.Text = Nothing
        txtChildren.Text = "0"
        txtAdults.Text = "0"
        cboDiscount.Refresh()
        txtAdvance.Text = Nothing
        txtSubTotal.Text = Nothing
        txtTotal.Text = Nothing
        lblDiscountID.Text = Nothing
        lblDiscountRate.Text = Nothing
        lbl_GuestID.Text = Nothing
        lblAdvancePayment.Text = Nothing
        lblNoOfOccupancy.Text = "0"

        Dim time As DateTime = DateTime.Now
        Dim format As String = "d/MM/yyyy"
        txtCheckInDate.Text = time.ToString(format)
        dtCheckOutDate.Text = Now.AddDays(1D)
    End Sub

    Private Sub pop_discount()
        Call con.Close()
        Call con.Open()
        Dim dt As New DataTable
        rs = New OleDbDataAdapter("SELECT * FROM tblDiscount", con)
        Call rs.Fill(dt)

        Call cboDiscount.Items.Clear()
        Dim i As Integer
        For i = 0 To dt.Rows.Count - 1
            cboDiscount.Items.Add(dt.Rows(i).Item("DiscountType"))
        Next
        Call rs.Dispose()
        Call con.Close()
    End Sub

    Private Sub bttnSearchGuest_Click(sender As Object, e As EventArgs) Handles bttnSearchGuest.Click
        Call selectGuest.ShowDialog()
    End Sub

    Private Sub bttnSearchRoom_Click(sender As Object, e As EventArgs) Handles bttnSearchRoom.Click
        Call selectRoom.ShowDialog()
    End Sub

    Private Sub dtCheckOutDate_ValueChanged(sender As Object, e As EventArgs) Handles dtCheckOutDate.ValueChanged
        Dim T As TimeSpan = dtCheckOutDate.Value - Now
        If T.Days < 1 Then
            dtCheckOutDate.Text = Now.AddDays(1D)
            txtDaysNumber.Text = "1"
        Else
            txtDaysNumber.Text = T.Days + 1
        End If
        lblTotal.Text = Val(txtRoomRate.Text) * Val(txtDaysNumber.Text)
        txtSubTotal.Text = Val(txtRoomRate.Text) * Val(txtDaysNumber.Text)
    End Sub

    Private Sub bttnSubAdult_Click(sender As Object, e As EventArgs) Handles bttnSubAdult.Click
        If Val(txtAdults.Text) = 0 Then
            txtAdults.Text = Val(txtAdults.Text)
        Else
            txtAdults.Text = Val(txtAdults.Text) - 1
        End If
    End Sub

    Private Sub bttnAddAdult_Click(sender As Object, e As EventArgs) Handles bttnAddAdult.Click
        Dim tao As Integer
        tao = Val(txtAdults.Text) + Val(txtChildren.Text)
        If tao = Val(lblNoOfOccupancy.Text) Then

        Else
            txtAdults.Text = Val(txtAdults.Text) + 1
        End If
    End Sub

    Private Sub bttnSubChildren_Click(sender As Object, e As EventArgs) Handles bttnSubChildren.Click
        If Val(txtChildren.Text) = 0 Then
            txtChildren.Text = Val(txtChildren.Text)
        Else
            txtChildren.Text = Val(txtChildren.Text) - 1
        End If
    End Sub

    Private Sub bttnAddChildren_Click(sender As Object, e As EventArgs) Handles bttnAddChildren.Click
        Dim tao As Integer
        tao = Val(txtAdults.Text) + Val(txtChildren.Text)
        If tao = Val(lblNoOfOccupancy.Text) Then

        Else
            txtChildren.Text = Val(txtChildren.Text) + 1
        End If
    End Sub

    Private Sub cboDiscount_TextChanged(sender As Object, e As EventArgs) Handles cboDiscount.TextChanged
        Call con.Close()
        Call con.Open()
        Dim dt As New DataTable
        rs = New OleDbDataAdapter("SELECT * FROM tblDiscount WHERE DiscountType = '" & cboDiscount.Text & "'", con)
        Call rs.Fill(dt)

        lblDiscountID.Text = dt.Rows(0).Item("ID")
        lblDiscountRate.Text = dt.Rows(0).Item("DiscountRate")

        txtSubTotal.Text = (Val(lblTotal.Text) - (Val(lblTotal.Text) * Val(lblDiscountRate.Text))).ToString("00.00")
        lblAdvancePayment.Text = "Advance Payment Must Be At Least $" & (Val(txtSubTotal.Text) * 0.5).ToString("00.00")
        Call rs.Dispose()
        Call con.Close()
    End Sub

    Private Sub txtAdvance_TextChanged(sender As Object, e As EventArgs) Handles txtAdvance.TextChanged
        If Val(txtSubTotal.Text) < Val(txtAdvance.Text) Or Val(txtSubTotal.Text) = Val(txtAdvance.Text) Then
            txtTotal.Text = "0.00"
        Else
            txtTotal.Text = (Val(txtSubTotal.Text) - Val(txtAdvance.Text)).ToString("00.00")
        End If
    End Sub

    Private Sub btnCheckIn_Click(sender As Object, e As EventArgs) Handles btnCheckIn.Click
        If txtAdvance.Text > lblAdvancePayment.Text Then
            MessageBox.Show("The Transaction Amount Is Less Than Minimum Amount Defined For This Service", "Notification", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        Else
            Call checkIn()
        End If
    End Sub

    Private Sub btn_Cancel_Click(sender As Object, e As EventArgs) Handles btn_Cancel.Click
        Call clear_text()
    End Sub

    Private Sub txtAdvance_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtAdvance.KeyPress
        If (e.KeyChar < "0" OrElse e.KeyChar > "9") AndAlso e.KeyChar <> ControlChars.Back AndAlso e.KeyChar <> "." Then
            'cancel keys
            e.Handled = True
        End If
    End Sub
End Class