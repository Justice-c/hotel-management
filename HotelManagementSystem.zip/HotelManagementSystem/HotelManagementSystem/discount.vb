﻿Imports System.Data.OleDb
Public Class discount
    Dim id_num As Integer
    Dim update_discount As Boolean = False

    Private Sub bttnSave_Click(sender As Object, e As EventArgs) Handles bttnSave.Click
        Call save_Discount()
    End Sub

    Private Sub discount_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call display_discount()
        Call clear()
        Call btn_delete.Hide()
    End Sub
    Private Sub clear()
        txtType.Text = Nothing
        txtRate.Text = Nothing
    End Sub

    Private Sub display_discount()
        Call con.Close()
        Call con.Open()
        Dim dt As New DataTable("tblDiscount")
        rs = New OleDbDataAdapter("SELECT * FROM tblDiscount", con)
        Call rs.Fill(dt)

        Call lvlDiscount.Items.Clear()

        Dim indx As Integer
        For indx = 0 To dt.Rows.Count - 1
            Dim lv As New ListViewItem
            lv.Text = dt.Rows(indx).Item("ID")
            lv.SubItems.Add(dt.Rows(indx).Item("DiscountType"))
            lv.SubItems.Add(dt.Rows(indx).Item("DiscountRate"))
            lvlDiscount.Items.Add(lv)
        Next
        Call rs.Dispose()
        Call con.Close()
    End Sub

    Private Sub save_Discount()
        Dim type As String = Trim(txtType.Text)
        Dim rate As String = Trim(txtRate.Text)
        Dim status As String = "Available"
        Dim a As String = MessageBox.Show("Save Discount Info", "Notification", MessageBoxButtons.YesNo, MessageBoxIcon.Question)

        If Trim(txtType.Text) = Nothing Or Trim(txtRate.Text) = Nothing Then
            Call MessageBox.Show("Fill All Fields", "Notification", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Exit Sub
        End If

        If a = vbYes Then
            If update_discount = False Then
                Call con.Close()
                Call con.Open()
                Dim save As New OleDbCommand("INSERT INTO tblDiscount(DiscountType,DiscountRate,Status) values ('" & Trim(txtType.Text) & "','" & Trim(txtRate.Text) & "','Active')", con)
                Call save.ExecuteNonQuery()
                Call con.Close()
                Call MessageBox.Show("Data saved successfully", "Notification", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Call display_discount()
            Else
                If bttnSave.Text = "UPDATE" Then
                    Call con.Close()
                    Call con.Open()
                    Dim activate_room As New OleDbCommand("UPDATE tblDiscount SET DiscountType= '" & SafeSqlLiteral(type, 2) & "',DiscountRate = '" & SafeSqlLiteral(rate, 2) & "',Status = '" & SafeSqlLiteral(status, 2) & "' WHERE ID = " & id_num & "", con)
                    Call activate_room.ExecuteNonQuery()
                    Call activate_room.Dispose()
                    Call con.Close()
                    bttnSave.Text = "SAVE"
                    Call MessageBox.Show("Discount Successfully Updated", "Notification", MessageBoxButtons.OK, MessageBoxIcon.Information)
                End If
            End If
            Call display_discount()
            Call clear()
            Call btn_delete.Hide()
        Else
            Call btn_delete.Hide()
        End If
    End Sub

    Private Sub select_DiscountInfo()
        Dim a As String = MessageBox.Show("Confirm Update Discount", "Notification", MessageBoxButtons.YesNo, MessageBoxIcon.Information)
        If a = vbYes Then
            id_num = lvlDiscount.SelectedItems(0).Text
            txtType.Text = lvlDiscount.SelectedItems(0).SubItems(1).Text
            txtRate.Text = Val(lvlDiscount.SelectedItems(0).SubItems(2).Text)
            update_discount = True
            bttnSave.Text = "UPDATE"
            Call btn_delete.Show()
        Else
            Call btn_delete.Hide()
        End If
    End Sub

    Private Sub lvlDiscount_DoubleClick(sender As Object, e As EventArgs) Handles lvlDiscount.DoubleClick
        Call select_DiscountInfo()
    End Sub

    Private Sub delete_Discount()
        Call con.Close()
        Call con.Open()
        Dim a As String = MessageBox.Show("Confirm Delete Discount", "Notification", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        ' Check if identifier that holds Message box for checkin confirmation is true
        If a = vbYes Then
            If btn_delete.Text = "DELETE" Then
                Dim delete_room As New OleDbCommand("DELETE * FROM tblDiscount WHERE ID = " & id_num & "", con)
                Call delete_room.ExecuteNonQuery()
                Call delete_room.Dispose()
                Call MessageBox.Show("Discount Successfully Deleted", "Notification", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Call btn_delete.Hide()
            End If
        End If
        Call Refresh()
        Call con.Close()
        bttnSave.Text = "SAVE"
        Call clear()
        Call display_discount()
    End Sub

    Private Sub btn_delete_Click(sender As Object, e As EventArgs) Handles btn_delete.Click
        Call delete_Discount()
    End Sub

    Private Sub txtRate_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtRate.KeyPress
        If (e.KeyChar < "0" OrElse e.KeyChar > "9") AndAlso e.KeyChar <> ControlChars.Back AndAlso e.KeyChar <> "." Then
            'cancel keys
            e.Handled = True
        End If
    End Sub

    Private Sub bttnCancel_Click(sender As Object, e As EventArgs) Handles bttnCancel.Click
        Call clear()
        Call btn_delete.Hide()
        bttnSave.Text = "SAVE"
    End Sub
End Class