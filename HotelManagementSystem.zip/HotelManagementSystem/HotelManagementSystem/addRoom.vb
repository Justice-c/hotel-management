﻿Imports System.Data.OleDb
Public Class addRoom

    Private Sub addRoom_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call loadForm()
    End Sub

    Private Sub loadForm()
        If (lbl_Status.Text = "Occupied") Then
            btn_Activate.Hide()
            btn_Deactivate.Hide()
            btnUpdate.Show()
            btn_Delete.Show()
        ElseIf (lbl_Status.Text = "Deactivated") Then
            btn_Activate.Show()
            btn_Deactivate.Hide()
            btnUpdate.Show()
            btn_Delete.Show()
        ElseIf (lbl_Status.Text = "Available") Then
            btn_Activate.Hide()
            btn_Deactivate.Show()
            btnUpdate.Show()
            btn_Delete.Show()
        Else
            bttnSave.Show()
            btn_Cancel.Show()
            btn_Activate.Hide()
            btn_Deactivate.Hide()
            btnUpdate.Hide()
            btn_Delete.Hide()
        End If
    End Sub

    Private Sub bttnSave_Click(sender As Object, e As EventArgs) Handles bttnSave.Click
        Call add_Room()
    End Sub

    Private Sub add_Room()
        Call con.Close()
        Call con.Open()
        Dim num As String = Trim(txtID.Text)
        Dim type As String = Trim(txtRoomType.Text)
        Dim rate As String = Trim(txtRoomRate.Text)
        Dim occupancy As String = Trim(txtNoOfOccupancy.Text)
        Dim stat As String = "Available"
        If type = Nothing Or rate = Nothing Or occupancy = Nothing Then
            Call MessageBox.Show("Please Fill All Fields", "Notification", MessageBoxButtons.OK, MessageBoxIcon.Error)

        ElseIf bttnSave.Text = "SAVE" Then
            Call save("INSERT INTO tblRoom(RoomNumber,RoomType,RoomRate,NoOfOccupancy,Status) values ('" &
                                                 num & "','" &
                                                 type & "','" &
                                                 rate & "','" &
                                                 occupancy & "','" &
                                                 stat & "')")
            Call con.Close()
        Else
            Call MessageBox.Show("Room Number Existed", "Notification", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        End If
    End Sub


    Private Sub update_Rooms()
        Call con.Close()
        Call con.Open()
        Dim num As String = Trim(txtID.Text)
        Dim type As String = Trim(txtRoomType.Text)
        Dim rate As String = Trim(txtRoomRate.Text)
        Dim occupancy As String = Trim(txtNoOfOccupancy.Text)
        Dim stat As String = "Available"
        If btnUpdate.Text = "UPDATE" Then
            Dim update_room As New OleDbCommand("UPDATE tblRoom SET RoomNumber= '" & SafeSqlLiteral(num, 2) & "',RoomType = '" & SafeSqlLiteral(type, 2) & "',RoomRate = '" & SafeSqlLiteral(rate, 2) & "',NoOfOccupancy = '" & SafeSqlLiteral(occupancy, 2) & "' WHERE ID = " & lbl_RoomID.Text & "", con)
            Call update_room.ExecuteNonQuery()
            Call update_room.Dispose()
            Call MessageBox.Show("Room Successfully Updated", "Notification", MessageBoxButtons.OK, MessageBoxIcon.Information)
        End If
        Me.Close()
        Call con.Close()
    End Sub

    Private Sub delete_Rooms()
        Call con.Close()
        Call con.Open()
        Dim a As String = MessageBox.Show("Confirm Delete Room", "Notification", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        ' Check if identifier that holds Message box for checkin confirmation is true
        If a = vbYes Then
            If btn_Delete.Text = "DELETE" Then
                Dim delete_room As New OleDbCommand("DELETE * FROM tblRoom WHERE ID = " & lbl_RoomID.Text & "", con)
                Call delete_room.ExecuteNonQuery()
                Call delete_room.Dispose()
                MessageBox.Show("Room Successfully Deleted", "Notification", MessageBoxButtons.OK, MessageBoxIcon.Information)
            End If
        End If
        Call Me.Close()
        Call con.Close()
    End Sub

    Private Sub deactivate_Rooms()
        If (lbl_Status.Text = "Occupied") Then
            Call MessageBox.Show("Room Successfully Activated", "Notification", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Else
            Dim num As String = Trim(txtID.Text)
            Dim type As String = Trim(txtRoomType.Text)
            Dim rate As String = Trim(txtRoomRate.Text)
            Dim occupancy As String = Trim(txtNoOfOccupancy.Text)
            Dim status As String = "Deactivated"
            Call con.Close()
            Call con.Open()
            Dim a As String = MessageBox.Show("Confirm Deactivating Room", "Notification", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
            ' Check if identifier that holds Message box for checkin confirmation is true
            If a = vbYes Then
                If btn_Deactivate.Text = "DEACTIVATE" Then
                    Dim deactivated_room As New OleDbCommand("UPDATE tblRoom SET RoomNumber= '" & SafeSqlLiteral(num, 2) & "',RoomType = '" & SafeSqlLiteral(type, 2) & "',RoomRate = '" & SafeSqlLiteral(rate, 2) & "',NoOfOccupancy = '" & SafeSqlLiteral(occupancy, 2) & "',Status = '" & SafeSqlLiteral(status, 2) & "' WHERE ID = " & lbl_RoomID.Text & "", con)
                    Call deactivated_room.ExecuteNonQuery()
                    Call deactivated_room.Dispose()
                    Call MessageBox.Show("Room Successfully DeActivated", "Notification", MessageBoxButtons.OK, MessageBoxIcon.Information)
                End If
            End If
            Call Me.Close()
            Call con.Close()
        End If
    End Sub

    Private Sub activate_Rooms()
        Dim num As String = Trim(txtID.Text)
        Dim type As String = Trim(txtRoomType.Text)
        Dim rate As String = Trim(txtRoomRate.Text)
        Dim occupancy As String = Trim(txtNoOfOccupancy.Text)
        Dim status As String = "Available"
        Call con.Close()
        Call con.Open()
        Dim a As String = MessageBox.Show("Confirm Activate Room", "Notification", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        ' Check if identifier that holds Message box for checkin confirmation is true
        If a = vbYes Then
            If btn_Activate.Text = "ACTIVATE" Then
                Dim activate_room As New OleDbCommand("UPDATE tblRoom SET RoomNumber= '" & SafeSqlLiteral(num, 2) & "',RoomType = '" & SafeSqlLiteral(type, 2) & "',RoomRate = '" & SafeSqlLiteral(rate, 2) & "',NoOfOccupancy = '" & SafeSqlLiteral(occupancy, 2) & "',Status = '" & SafeSqlLiteral(status, 2) & "' WHERE ID = " & lbl_RoomID.Text & "", con)
                Call activate_room.ExecuteNonQuery()
                Call activate_room.Dispose()
                Call MessageBox.Show("Room Successfully Activated", "Notification", MessageBoxButtons.OK, MessageBoxIcon.Information)
            End If
        End If
        Call Me.Close()
        Call con.Close()
    End Sub

    Private Sub bttn_Cancel_Click(sender As Object, e As EventArgs) Handles btn_Cancel.Click
        Call clear()
    End Sub

    Private Sub clear()
        txtID.Text = Nothing
        txtRoomType.Text = Nothing
        txtRoomRate.Text = Nothing
        txtNoOfOccupancy.Text = Nothing

        txtID.BackColor = Color.White
    End Sub

    Private Sub txtID_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtID.KeyPress
        If (Not Char.IsControl(e.KeyChar) _
                     AndAlso (Not Char.IsDigit(e.KeyChar))) Then
            e.Handled = True
        End If
    End Sub

    Private Sub txtRoomRate_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtRoomRate.KeyPress
        If (Not Char.IsControl(e.KeyChar) _
                     AndAlso (Not Char.IsDigit(e.KeyChar))) Then
            e.Handled = True
        End If
    End Sub

    Private Sub txtNoOfOccupancy_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtNoOfOccupancy.KeyPress
        If (Not Char.IsControl(e.KeyChar) _
                     AndAlso (Not Char.IsDigit(e.KeyChar))) Then
            e.Handled = True
        End If
    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        Call update_Rooms()
        Call roomsList.loadMain()
    End Sub

    Private Sub btn_Delete_Click(sender As Object, e As EventArgs) Handles btn_Delete.Click
        Call delete_Rooms()
        Call roomsList.loadMain()
    End Sub

    Private Sub btn_Deactivate_Click(sender As Object, e As EventArgs) Handles btn_Deactivate.Click
        If lbl_Status.Text = "Occupied" Then
            MessageBox.Show("Room Is Occupied", "Notification", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Else
            Call deactivate_Rooms()
            Call roomsList.loadMain()
        End If
    End Sub

    Private Sub btn_Activate_Click(sender As Object, e As EventArgs) Handles btn_Activate.Click
        If lbl_Status.Text = "Occupied" Then
            MessageBox.Show("Room Is Occupied", "Notification", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Else
            Call activate_Rooms()
            Call roomsList.loadMain()
        End If
    End Sub
End Class