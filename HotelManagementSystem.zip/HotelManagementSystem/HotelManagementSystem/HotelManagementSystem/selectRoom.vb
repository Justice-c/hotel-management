﻿Imports System.Data.OleDb
Public Class selectRoom

    Private Sub selectRoom_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call display_room()
    End Sub

    Private Sub display_room()
        Call con.Close()
        Call con.Open()
        Dim Dt As New DataTable("tblRoom")
        Dim rs As OleDbDataAdapter

        rs = New OleDbDataAdapter("Select * from tblRoom WHERE Status = 'Available' ORDER BY ID ASC", con)

        Call rs.Fill(Dt)
        Dim indx As Integer
        Call lvRoom.Items.Clear()
        For indx = 0 To Dt.Rows.Count - 1
            Dim lv As New ListViewItem
            lv.Text = Dt.Rows(indx).Item("RoomNumber")
            lv.SubItems.Add(Dt.Rows(indx).Item("RoomType"))
            lv.SubItems.Add(Dt.Rows(indx).Item("RoomRate"))
            lv.SubItems.Add(Dt.Rows(indx).Item("NoOfOccupancy"))
            Call lvRoom.Items.Add(lv)
        Next
        rs.Dispose()
        Call con.Close()
    End Sub

    Private Sub lvRoom_DoubleClick(sender As Object, e As EventArgs) Handles lvRoom.DoubleClick

        reserve.txtRoomNumber.Text = lvRoom.SelectedItems(0).Text
        reserve.txtRoomType.Text = lvRoom.SelectedItems(0).SubItems(1).Text
        reserve.txtRoomRate.Text = lvRoom.SelectedItems(0).SubItems(2).Text
        reserve.lblNoOfOccupancy.Text = lvRoom.SelectedItems(0).SubItems(3).Text
        reserve.lblNoOfOccupancy.Text = lvRoom.SelectedItems(0).SubItems(3).Text

        checkIn.txtRoomNumber.Text = lvRoom.SelectedItems(0).Text
        checkIn.txtRoomType.Text = lvRoom.SelectedItems(0).SubItems(1).Text
        checkIn.txtRoomRate.Text = lvRoom.SelectedItems(0).SubItems(2).Text
        checkIn.lblNoOfOccupancy.Text = lvRoom.SelectedItems(0).SubItems(3).Text
        checkIn.txtSubTotal.Text = lvRoom.SelectedItems(0).SubItems(2).Text

        checkIn.lblTotal.Text = lvRoom.SelectedItems(0).SubItems(2).Text
        Call Me.Close()
    End Sub
End Class