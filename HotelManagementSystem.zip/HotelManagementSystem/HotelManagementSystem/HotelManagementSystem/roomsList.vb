﻿Imports System.Data.OleDb
Public Class roomsList
    Dim LV_Ghost As New ListView

    Private Sub roomsList_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call loadMain()
    End Sub

    Public Sub loadMain()
        Call con.Close()
        Call con.Open()
        Dim Dt As New DataTable("tblRoom")
        Dim rs As OleDbDataAdapter

        rs = New OleDbDataAdapter("Select * from tblRoom ORDER BY RoomNumber ASC;", con)

        Call rs.Fill(Dt)
        Dim indx As Integer
        Call lvRoom.Items.Clear()
        For indx = 0 To Dt.Rows.Count - 1
            Dim lv As New ListViewItem
            lv.Text = Dt.Rows(indx).Item("ID")
            lv.SubItems.Add(Dt.Rows(indx).Item("RoomNumber"))
            lv.SubItems.Add(Dt.Rows(indx).Item("RoomType"))
            lv.SubItems.Add(Dt.Rows(indx).Item("RoomRate"))
            lv.SubItems.Add(Dt.Rows(indx).Item("NoOfOccupancy"))
            lv.SubItems.Add(Dt.Rows(indx).Item("Status"))
            lvRoom.Items.Add(lv)
        Next
        Call rs.Dispose()
        Call con.Close()
    End Sub

    Private Sub lvRoom_DoubleClick(sender As Object, e As EventArgs) Handles lvRoom.DoubleClick
        Call ManageRoom()
    End Sub

    Private Sub ManageRoom()
        addRoom.lbl_Heading.Text = "MANAGE ROOM"
        addRoom.bttnSave.Hide()
        addRoom.btn_Cancel.Hide()
        addRoom.btnUpdate.Show()
        addRoom.btn_Activate.Show()
        addRoom.btn_Deactivate.Show()
        addRoom.btn_Delete.Show()
        addRoom.lbl_RoomID.Text = lvRoom.SelectedItems(0).SubItems(0).Text
        addRoom.txtID.Text = lvRoom.SelectedItems(0).SubItems(1).Text
        addRoom.txtRoomType.Text = lvRoom.SelectedItems(0).SubItems(2).Text
        addRoom.txtRoomRate.Text = lvRoom.SelectedItems(0).SubItems(3).Text
        addRoom.txtNoOfOccupancy.Text = lvRoom.SelectedItems(0).SubItems(4).Text
        addRoom.lbl_Status.Text = lvRoom.SelectedItems(0).SubItems(5).Text

        Call addRoom.ShowDialog()
    End Sub

    Private Sub txt_SearchRoomID_TextChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click
        lvRoom.MultiSelect = False
        lvRoom.FullRowSelect = True
        Dim checkInt As Integer = FindItem(lvRoom, txt_SearchRoomID.Text)
        If checkInt <> -1 Then
            lvRoom.Items(checkInt).Selected = True
            Call lvRoom.Focus()
        Else
            Call MessageBox.Show("Room Number Not Found", "Notification", MessageBoxButtons.OK, MessageBoxIcon.Information)
        End If
    End Sub
End Class
