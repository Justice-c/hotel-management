﻿Imports System.Data.OleDb
Public Class reserveList

    Private Sub reserveList_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call display_reserve()
    End Sub

    Private Sub display_reserve()
        Call con.Close()
        Call con.Open()
        Dim Dt As New DataTable("tblGuest")
        Dim rs As OleDbDataAdapter

        rs = New OleDbDataAdapter("Select * from tblTransaction, tblGuest, tblDiscount, tblRoom WHERE tblTransaction.GuestID = tblGuest.ID AND tblTransaction.DiscountID = tblDiscount.ID AND tblTransaction.RoomNum = tblRoom.RoomNumber AND tblTransaction.Remarks = 'Reserve'", con)

        Call rs.Fill(Dt)
        Dim indx As Integer
        Call lvlreserve.Items.Clear()
        For indx = 0 To Dt.Rows.Count - 1
            Dim lv As New ListViewItem
            Dim getdate As TimeSpan
            Dim days, subtotal, total, rate As Integer
            Dim discount As Double

            Dim value As Integer = Val(Dt.Rows(indx).Item("TransID"))

            lv.Text = value.ToString("0000")
            lv.SubItems.Add(Dt.Rows(indx).Item("GuestContactNumber"))
            lv.SubItems.Add(Dt.Rows(indx).Item("RoomNum"))

            rate = Dt.Rows(indx).Item("RoomRate")

            lv.SubItems.Add(Dt.Rows(indx).Item("CheckInDate"))
            lv.SubItems.Add(Dt.Rows(indx).Item("CheckOutDate"))

            dtIn.Value = Dt.Rows(indx).Item("CheckOutDate")
            dtOut.Value = Dt.Rows(indx).Item("CheckInDate")

            getdate = dtIn.Value - dtOut.Value
            days = getdate.Days

            lv.SubItems.Add(days)
            lv.SubItems.Add(Dt.Rows(indx).Item("NoOfChild"))
            lv.SubItems.Add(Dt.Rows(indx).Item("NoOfAdult"))
            lv.SubItems.Add(Dt.Rows(indx).Item("AdvancePayment"))
            lv.SubItems.Add(Dt.Rows(indx).Item("DiscountType"))

            discount = Val(Dt.Rows(indx).Item("DiscountRate"))

            subtotal = (days * rate) - ((days * rate) * discount)

            total = Val(subtotal) - Val(Dt.Rows(indx).Item("AdvancePayment"))

            Call lv.SubItems.Add(Val(total))
            Call lvlreserve.Items.Add(lv)
        Next
        Call rs.Dispose()
        Call con.Close()
    End Sub

    Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click
        lvlreserve.MultiSelect = False
        lvlreserve.FullRowSelect = True
        Dim checkInt As Integer = FindItem(lvlreserve, txt_Search.Text)
        If checkInt <> -1 Then
            lvlreserve.Items(checkInt).Selected = True
            Call lvlreserve.Focus()
        Else
            Call MessageBox.Show("Room Number Not Found", "Notification", MessageBoxButtons.OK, MessageBoxIcon.Information)
        End If
    End Sub
End Class