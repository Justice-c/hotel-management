﻿Imports System.Data.OleDb
Public Class selectGuest

    Private Sub selectGuest_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call display_guest()
    End Sub

    Private Sub display_guest()
        Call con.Close()
        Call con.Open()
        Dim Dt As New DataTable("tblGuest")
        Dim rs As OleDbDataAdapter

        rs = New OleDbDataAdapter("Select * from tblGuest WHERE Remarks = 'Available' ORDER BY ID ASC;", con)

        Call rs.Fill(Dt)
        Dim indx As Integer
        Call lvGuest.Items.Clear()
        For indx = 0 To Dt.Rows.Count - 1
            Dim lv As New ListViewItem
            lv.Text = Dt.Rows(indx).Item("ID")
            lv.SubItems.Add(Dt.Rows(indx).Item("GuestFName"))
            lv.SubItems.Add(Dt.Rows(indx).Item("GuestMName"))
            lv.SubItems.Add(Dt.Rows(indx).Item("GuestLName"))
            lvGuest.Items.Add(lv)
        Next
        Call rs.Dispose()
        Call con.Close()
    End Sub

    Private Sub lvGuest_DoubleClick(sender As Object, e As EventArgs) Handles lvGuest.DoubleClick
        checkIn.lbl_GuestID.Text = lvGuest.SelectedItems(0).Text
        checkIn.txtGuestName.Text = lvGuest.SelectedItems(0).SubItems(1).Text & " " &
            lvGuest.SelectedItems(0).SubItems(2).Text & " " &
            lvGuest.SelectedItems(0).SubItems(3).Text

        reserve.lblGuestID.Text = lvGuest.SelectedItems(0).Text
        reserve.txtGuestName.Text = lvGuest.SelectedItems(0).SubItems(1).Text & " " & lvGuest.SelectedItems(0).SubItems(2).Text & " " & lvGuest.SelectedItems(0).SubItems(3).Text
        Call Me.Close()
    End Sub
End Class