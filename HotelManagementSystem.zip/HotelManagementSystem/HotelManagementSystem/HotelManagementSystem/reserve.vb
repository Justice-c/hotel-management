﻿Imports System.Data.OleDb
Public Class reserve
    Dim trans_id As String
    Private Sub reserve_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call clear()
        Dim time As DateTime = DateTime.Now
        Dim format As String = "d/MM/yyyy"
        dtCheckInDate.Text = time.ToString(format)
        dtCheckOutDate.Text = dtCheckInDate.Value.Date.AddDays(1D)
        lblDateNow.Text = Now.Date
        Call transID()
        Call pop_discount()
        lvreserve.DataSource = getReserved()
    End Sub
    Private Sub bttnSearchGuest_Click(sender As Object, e As EventArgs) Handles bttnSearchGuest.Click
        Call selectGuest.ShowDialog()
    End Sub

    Private Sub bttnSearchRoom_Click(sender As Object, e As EventArgs) Handles bttnSearchRoom.Click
        Call selectRoom.ShowDialog()
    End Sub

    Private Sub clear()
        txtGuestName.Text = Nothing
        txtRoomNumber.Text = Nothing
        txtRoomType.Text = Nothing
        txtRoomRate.Text = Nothing
        txtChildren.Text = "0"
        txtAdults.Text = "0"
        cboDiscount.Refresh()
        txtAdvance.Text = Nothing
        txtSubTotal.Text = Nothing
        txtBalance.Text = Nothing
        lblDiscountID.Text = Nothing
        lblDiscountRate.Text = Nothing
        lblGuestID.Text = Nothing
        lblAdvancePayment.Text = Nothing
        lblAdvancePayment1.Text = Nothing
        lblNoOfOccupancy.Text = "0"

        Dim time As DateTime = DateTime.Now
        Dim format As String = "d/MM/yyyy"
        dtCheckInDate.Text = time.ToString(format)
        dtCheckOutDate.Text = Now.AddDays(1D)
    End Sub

    Public Sub transID()
        Try
            Call con.Close()
            Call con.Open()
            Dim dt As New DataTable("tblTransaction")
            rs = New OleDbDataAdapter("SELECT * FROM tblTransaction ORDER BY TransID DESC", con)
            Call rs.Fill(dt)

            If dt.Rows.Count = 0 Then
                txtTransID.Text = "10001"
            Else
                Dim value As Integer = Val(dt.Rows(0).Item("TransID"))
                value = value + 1
                txtTransID.Text = value.ToString("0000")
            End If
            Call rs.Dispose()
            Call con.Close()
        Catch ex As Exception

        Finally
            Call con.Close()
        End Try


    End Sub

    Private Sub pop_discount()
        Call con.Close()
        Call con.Open()
        Dim dt As New DataTable
        rs = New OleDbDataAdapter("SELECT * FROM tblDiscount", con)
        Call rs.Fill(dt)

        Call cboDiscount.Items.Clear()
        Dim i As Integer
        For i = 0 To dt.Rows.Count - 1
            Call cboDiscount.Items.Add(dt.Rows(i).Item("DiscountType"))
        Next
        Call rs.Dispose()
        Call con.Close()
    End Sub


    Private Sub txtRoomRate_TextChanged(sender As Object, e As EventArgs) Handles txtRoomRate.TextChanged
        lblTotal.Text = Val(txtRoomRate.Text) * Val(txtDaysNumber.Text)
        txtSubTotal.Text = Val(txtRoomRate.Text) * Val(txtDaysNumber.Text)
    End Sub

    Private Sub dtCheckInDate_ValueChanged(sender As Object, e As EventArgs) Handles dtCheckInDate.ValueChanged
        Dim t As Date = dtCheckInDate.Value
        If t.Date < Now.Date Then
            dtCheckInDate.Value = Now.Date
        Else
            dtCheckOutDate.Value = dtCheckInDate.Value.Date.AddDays(1D)
        End If
    End Sub

    Private Sub dtCheckOutDate_ValueChanged(sender As Object, e As EventArgs) Handles dtCheckOutDate.ValueChanged
        Dim T As TimeSpan = dtCheckOutDate.Value - dtCheckInDate.Value
        If T.Days < 1 Then
            dtCheckOutDate.Text = dtCheckInDate.Value.Date.AddDays(1D)
            txtDaysNumber.Text = "1"
        Else
            txtDaysNumber.Text = T.Days
        End If
        lblTotal.Text = Val(txtRoomRate.Text) * Val(txtDaysNumber.Text)
        txtSubTotal.Text = Val(txtRoomRate.Text) * Val(txtDaysNumber.Text)
        lblDateNow.Text = Now.Date
        txtBalance.Text = -1
    End Sub

    Private Sub bttnSubAdult_Click(sender As Object, e As EventArgs) Handles bttnSubAdult.Click
        If Val(txtAdults.Text) = 0 Then
            txtAdults.Text = Val(txtAdults.Text)
        Else
            txtAdults.Text = Val(txtAdults.Text) - 1
        End If
    End Sub

    Private Sub bttnAddAdult_Click(sender As Object, e As EventArgs) Handles bttnAddAdult.Click
        Dim tao As Integer
        tao = Val(txtAdults.Text) + Val(txtChildren.Text)
        If tao = Val(lblNoOfOccupancy.Text) Then

        Else
            txtAdults.Text = Val(txtAdults.Text) + 1
        End If
    End Sub

    Private Sub bttnSubChildren_Click(sender As Object, e As EventArgs) Handles bttnSubChildren.Click
        If Val(txtChildren.Text) = 0 Then
            txtChildren.Text = Val(txtChildren.Text)
        Else
            txtChildren.Text = Val(txtChildren.Text) - 1
        End If
    End Sub

    Private Sub bttnAddChildren_Click(sender As Object, e As EventArgs) Handles bttnAddChildren.Click
        Dim tao As Integer
        tao = Val(txtAdults.Text) + Val(txtChildren.Text)
        If tao = Val(lblNoOfOccupancy.Text) Then

        Else
            txtChildren.Text = Val(txtChildren.Text) + 1
        End If
    End Sub

    Private Sub cboDiscount_TextChanged(sender As Object, e As EventArgs) Handles cboDiscount.TextChanged
        Call con.Close()
        Call con.Open()
        Dim dt As New DataTable
        rs = New OleDbDataAdapter("SELECT * FROM tblDiscount WHERE DiscountType = '" & cboDiscount.Text & "'", con)
        Call rs.Fill(dt)

        lblDiscountID.Text = dt.Rows(0).Item("ID")
        lblDiscountRate.Text = dt.Rows(0).Item("DiscountRate")

        txtSubTotal.Text = Val(lblTotal.Text) - (Val(lblTotal.Text) * Val(lblDiscountRate.Text))
        lblAdvancePayment1.Text = "To Reserve This Room Allocated Amount Must Be Paid First!"
        Call rs.Dispose()
        Call con.Close()
    End Sub

    Private Sub txtAdvance_TextChanged(sender As Object, e As EventArgs) Handles txtAdvance.TextChanged
        txtBalance.Text = Val(txtAdvance.Text) - Val(txtSubTotal.Text)
    End Sub

    Private Sub reserve()
        Try
            If (txtBalance.Text < 0 Or txtBalance.Text > 0) Then
                Call MessageBox.Show("To Reserve This Room Allocated Amount Must Be Paid First!", "Notification", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Else
                Dim children As Integer = Val(txtChildren.Text)
                Dim adult As Integer = Val(txtAdults.Text)
                Dim advance As Integer = Val(txtAdvance.Text)
                Dim discount As Integer = Val(lblDiscountID.Text)
                Dim reserve As String = "0"
                Dim remarks As String = "Reserve"
                Dim stat As String = "Active"

                If lblGuestID.Text = "GuestID" Or lblGuestID.Text = Nothing Or txtRoomNumber.Text = Nothing Or Val(children + adult) = Nothing Or advance = Nothing Or discount = Nothing Then
                    Call MessageBox.Show("Please Fill All Required Fields", "Notification", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Else
                    Dim a As String = MessageBox.Show("Confirm Reservation Transaction", "Notification", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                    If a = vbYes Then
                        Call con.Close()
                        Call con.Open()
                        Dim checkin As New OleDbCommand("INSERT INTO tblTransaction(GuestID,RoomNum,CheckInDate,CheckOutDate,ReservationDate,NoOfChild,NoOfAdult,AdvancePayment,DiscountID,Remarks,Status) values ('" &
                                                        lblGuestID.Text & "','" &
                                                        txtRoomNumber.Text & "','" &
                                                        dtCheckInDate.Text & "','" &
                                                        dtCheckOutDate.Text & "','" &
                                                        lblDateNow.Text & "','" &
                                                        txtChildren.Text & "','" &
                                                        txtAdults.Text & "','" &
                                                        txtAdvance.Text & "','" &
                                                        lblDiscountID.Text & "','" &
                                                        remarks & "','" &
                                                        stat & "')", con)
                        Call checkin.ExecuteNonQuery()

                        Dim update_guest As New OleDbCommand("UPDATE tblGuest SET Remarks = 'Reserve' WHERE ID = " & lblGuestID.Text & "", con)
                        Call update_guest.ExecuteNonQuery()

                        Dim update_room As New OleDbCommand("UPDATE tblRoom SET Status = 'Reserve' WHERE RoomNumber = " & txtRoomNumber.Text & "", con)
                        Call update_room.ExecuteNonQuery()

                        MessageBox.Show("Guest Successfully Reserved", "Notification", MessageBoxButtons.OK, MessageBoxIcon.Information)
                        Call clear()
                        Call con.Close()
                        Call transID()
                        lvreserve.DataSource = getReserved()
                    End If
                End If
            End If
        Catch ex As Exception
            Call MessageBox.Show("To Reserve This Room Allocated Amount Must Be Paid First!", "Notification", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        End Try
    End Sub

    Private Sub btnReserve_Click(sender As Object, e As EventArgs) Handles btnReserve.Click
        Call reserve()
    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        Call clear()
    End Sub

    Private Sub reserveCheckin(ByVal Transid As String, ByVal guestId As String, ByVal roomNum As String)
        Dim check_in As String = MessageBox.Show("Checkin Guest", "Notification", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        If lblTransaction.Text = "Transaction" Or lblGuest.Text = "Guest" Or lblRoom.Text = "Room" Then
            Call MessageBox.Show("Please Select Transaction", "Notification", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        ElseIf check_in = vbYes Then
            Call con.Close()
            Call con.Open()
            Dim update_trans As New OleDbCommand("UPDATE tblTransaction SET Remarks = 'Checkin' WHERE TransID = " & Transid & "", con)
            Call update_trans.ExecuteNonQuery()

            Dim update_guest As New OleDbCommand("UPDATE tblGuest SET Remarks = 'Checkin' WHERE ID = " & guestId & "", con)
            Call update_guest.ExecuteNonQuery()

            Dim update_room As New OleDbCommand("UPDATE tblRoom SET Status = 'Occupied' WHERE RoomNumber = " & roomNum & "", con)
            Call update_room.ExecuteNonQuery()
            Call con.Close()
            Call MessageBox.Show("Guest Checkedin", "Notification", MessageBoxButtons.OK, MessageBoxIcon.Information)
            lvreserve.DataSource = getReserved()
        End If
    End Sub

    Private Sub btnCheckin_Click(sender As Object, e As EventArgs) Handles btnCheckin.Click
        Call reserveCheckin(lblTransaction.Text, lblGuest.Text, lblRoom.Text)
    End Sub

    Private Sub reserveRemove(ByVal Transid As String, ByVal guestId As String, ByVal roomNum As String)
        Dim check_in As String = MessageBox.Show("Remove Reservation", "Notification", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        If lblTransaction.Text = "Transaction" Or lblGuest.Text = "Guest" Or lblRoom.Text = "Room" Then
            Call MessageBox.Show("Please Select Transaction", "Notification", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        ElseIf check_in = vbYes Then
            Call con.Close()
            Call con.Open()

            Dim update_trans As New OleDbCommand("UPDATE tblTransaction SET Remarks = 'Cancelled' WHERE TransID = " & Transid & "", con)
            Call update_trans.ExecuteNonQuery()

            Dim update_guest As New OleDbCommand("UPDATE tblGuest SET Remarks = 'Available' WHERE ID = " & guestId & "", con)
            Call update_guest.ExecuteNonQuery()

            Dim update_room As New OleDbCommand("UPDATE tblRoom SET Status = 'Available' WHERE RoomNumber = " & roomNum & "", con)
            Call update_room.ExecuteNonQuery()

            Call con.Close()
            Call MessageBox.Show("Reservation Cancelled", "Notification", MessageBoxButtons.OK, MessageBoxIcon.Information)
            lvreserve.DataSource = getReserved()
        End If
    End Sub

    Private Sub lvreserve_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles lvreserve.CellClick
        Try
            Dim index As Integer
            index = e.RowIndex
            Dim selectedRow As DataGridViewRow
            selectedRow = lvreserve.Rows(index)
            lblTransaction.Text = selectedRow.Cells(0).Value.ToString
            lblGuest.Text = selectedRow.Cells(1).Value.ToString
            lblRoom.Text = selectedRow.Cells(2).Value.ToString
        Catch ex As Exception
            Call MessageBox.Show("Invalid Selected Transaction", "Notification", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        End Try
    End Sub

    Private Sub btnCancelReserve_Click(sender As Object, e As EventArgs) Handles btnCancelReserve.Click
        Call reserveRemove(lblTransaction.Text, lblGuest.Text, lblRoom.Text)
    End Sub

    Private Sub searchData(valueToSearch As String)
        Call con.Close()
        Call con.Open()
        Dim searchQuery As String = "SELECT * FROM tblTransaction WHERE TransID like '%" & valueToSearch & "%' AND Remarks = 'Reserve';"
        Dim command As New OleDbCommand(searchQuery, con)
        Dim adapter As New OleDbDataAdapter(command)
        Dim table As New DataTable()

        Call adapter.Fill(table)
        lvreserve.DataSource = table
        Call con.Close()
    End Sub

    Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click
        Call searchData(txtSearch.Text)
    End Sub
End Class
