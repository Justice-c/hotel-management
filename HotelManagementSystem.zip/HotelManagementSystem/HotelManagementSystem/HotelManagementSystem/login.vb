﻿Imports System.Data.OleDb
Public Class login

    Private Sub btn_Login_Click(sender As Object, e As EventArgs) Handles btn_Login.Click
        Call login()
    End Sub

    Private Sub login()
        If Trim(txt_Username.Text) = Nothing Or Trim(txt_Password.Text) = Nothing Then
            Call MessageBox.Show("Please Enter Both Fields", "Notification", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Else
            Call con.Close()
            Call con.Open()
            Dim sql = "SELECT * FROM tblUser WHERE username = '" & SafeSqlLiteral(txt_Username.Text, 2) & "' AND password = '" & SafeSqlLiteral(txt_Password.Text, 2) & "'"

            Dim cmd = New OleDbCommand(sql, con)
            Dim dr As OleDbDataReader = cmd.ExecuteReader

            Try
                If dr.Read = False Then
                    lblMessage.Text = "Incorrect Username And Password"
                ElseIf dr(3) = "admin" Then
                    Call con.Close()
                    Call Me.Hide()
                    Call MainMenu.Show()
                ElseIf dr(3) = "employee" Then
                    Call con.Close()
                    MainMenu.btn_ManageDiscount.Enabled = False
                    Call Me.Hide()
                    Call MainMenu.Show()
                Else
                    lblMessage.Text = "Invalid Username And Password"
                End If
            Catch ex As Exception
                Call MessageBox.Show("Contact System Adminstrator", "Notification", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Finally
                Call con.Close()
            End Try
        End If
    End Sub

    Private Sub txt_Username_TextChanged(sender As Object, e As EventArgs) Handles txt_Username.TextChanged
        lblMessage.Text = Nothing
    End Sub

    Private Sub txt_Password_TextChanged(sender As Object, e As EventArgs) Handles txt_Password.TextChanged
        lblMessage.Text = Nothing
    End Sub

    Private Sub login_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class