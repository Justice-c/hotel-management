﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MainMenu
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub


    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(MainMenu))
        Me.ToolTip = New System.Windows.Forms.ToolTip(Me.components)
        Me.StatusStrip = New System.Windows.Forms.StatusStrip()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.MenuStrip = New System.Windows.Forms.MenuStrip()
        Me.file_Option = New System.Windows.Forms.ToolStripMenuItem()
        Me.help_Option = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.developer_Option = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator()
        Me.logout_Option = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator12 = New System.Windows.Forms.ToolStripSeparator()
        Me.reports_Option = New System.Windows.Forms.ToolStripMenuItem()
        Me.backup_Option = New System.Windows.Forms.ToolStripMenuItem()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.btn_RoomsList = New System.Windows.Forms.Button()
        Me.btn_CheckedInList = New System.Windows.Forms.Button()
        Me.btn_GuestList = New System.Windows.Forms.Button()
        Me.btn_CheckedoutList = New System.Windows.Forms.Button()
        Me.btn_ReservedList = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.btn_ReserveManagement = New System.Windows.Forms.Button()
        Me.btn_AddRoom = New System.Windows.Forms.Button()
        Me.btn_ManageDiscount = New System.Windows.Forms.Button()
        Me.btn_CheckOut = New System.Windows.Forms.Button()
        Me.btn_CheckIn = New System.Windows.Forms.Button()
        Me.btn_AddGuest = New System.Windows.Forms.Button()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lblUsername = New System.Windows.Forms.Label()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Panel2 = New System.Windows.Forms.Panel()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MenuStrip.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'StatusStrip
        '
        Me.StatusStrip.Location = New System.Drawing.Point(0, 727)
        Me.StatusStrip.Name = "StatusStrip"
        Me.StatusStrip.Size = New System.Drawing.Size(1370, 22)
        Me.StatusStrip.TabIndex = 7
        Me.StatusStrip.Text = "StatusStrip"
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(-11, 0)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(1392, 725)
        Me.PictureBox1.TabIndex = 9
        Me.PictureBox1.TabStop = False
        '
        'MenuStrip
        '
        Me.MenuStrip.BackColor = System.Drawing.Color.White
        Me.MenuStrip.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MenuStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.file_Option, Me.reports_Option, Me.backup_Option})
        Me.MenuStrip.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip.Name = "MenuStrip"
        Me.MenuStrip.Size = New System.Drawing.Size(1370, 28)
        Me.MenuStrip.TabIndex = 11
        Me.MenuStrip.Text = "MenuStrip"
        '
        'file_Option
        '
        Me.file_Option.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.help_Option, Me.ToolStripSeparator1, Me.developer_Option, Me.ToolStripSeparator3, Me.logout_Option, Me.ToolStripSeparator12})
        Me.file_Option.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.file_Option.Name = "file_Option"
        Me.file_Option.Size = New System.Drawing.Size(47, 24)
        Me.file_Option.Text = "FILE"
        '
        'help_Option
        '
        Me.help_Option.Name = "help_Option"
        Me.help_Option.Size = New System.Drawing.Size(208, 24)
        Me.help_Option.Text = "HELP"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(205, 6)
        '
        'developer_Option
        '
        Me.developer_Option.Name = "developer_Option"
        Me.developer_Option.Size = New System.Drawing.Size(208, 24)
        Me.developer_Option.Text = "ABOUT DEVELOPER"
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(205, 6)
        '
        'logout_Option
        '
        Me.logout_Option.Name = "logout_Option"
        Me.logout_Option.Size = New System.Drawing.Size(208, 24)
        Me.logout_Option.Text = "LOGOUT"
        '
        'ToolStripSeparator12
        '
        Me.ToolStripSeparator12.Name = "ToolStripSeparator12"
        Me.ToolStripSeparator12.Size = New System.Drawing.Size(205, 6)
        '
        'reports_Option
        '
        Me.reports_Option.Name = "reports_Option"
        Me.reports_Option.Size = New System.Drawing.Size(81, 24)
        Me.reports_Option.Text = "REPORTS"
        '
        'backup_Option
        '
        Me.backup_Option.Name = "backup_Option"
        Me.backup_Option.Size = New System.Drawing.Size(76, 24)
        Me.backup_Option.Text = "BACKUP"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.White
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 36.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.Orange
        Me.Label2.Location = New System.Drawing.Point(304, 142)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(751, 55)
        Me.Label2.TabIndex = 13
        Me.Label2.Text = "HOTEL MANAGEMENT SYSTEM"
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.Color.White
        Me.GroupBox2.BackgroundImage = CType(resources.GetObject("GroupBox2.BackgroundImage"), System.Drawing.Image)
        Me.GroupBox2.Controls.Add(Me.Panel4)
        Me.GroupBox2.Controls.Add(Me.btn_RoomsList)
        Me.GroupBox2.Controls.Add(Me.btn_CheckedInList)
        Me.GroupBox2.Controls.Add(Me.btn_GuestList)
        Me.GroupBox2.Controls.Add(Me.btn_CheckedoutList)
        Me.GroupBox2.Controls.Add(Me.btn_ReservedList)
        Me.GroupBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.ForeColor = System.Drawing.Color.Navy
        Me.GroupBox2.Location = New System.Drawing.Point(749, 319)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(578, 384)
        Me.GroupBox2.TabIndex = 14
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "MONITORING"
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.Color.Orange
        Me.Panel4.Location = New System.Drawing.Point(0, 349)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(578, 35)
        Me.Panel4.TabIndex = 7
        '
        'btn_RoomsList
        '
        Me.btn_RoomsList.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_RoomsList.FlatAppearance.BorderSize = 0
        Me.btn_RoomsList.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Orange
        Me.btn_RoomsList.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_RoomsList.Location = New System.Drawing.Point(330, 49)
        Me.btn_RoomsList.Name = "btn_RoomsList"
        Me.btn_RoomsList.Size = New System.Drawing.Size(233, 52)
        Me.btn_RoomsList.TabIndex = 10
        Me.btn_RoomsList.Text = "ROOMS LIST"
        Me.btn_RoomsList.UseVisualStyleBackColor = True
        '
        'btn_CheckedInList
        '
        Me.btn_CheckedInList.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_CheckedInList.FlatAppearance.BorderSize = 0
        Me.btn_CheckedInList.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Orange
        Me.btn_CheckedInList.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_CheckedInList.Location = New System.Drawing.Point(13, 49)
        Me.btn_CheckedInList.Name = "btn_CheckedInList"
        Me.btn_CheckedInList.Size = New System.Drawing.Size(233, 52)
        Me.btn_CheckedInList.TabIndex = 6
        Me.btn_CheckedInList.Text = "CHECKED IN LIST"
        Me.btn_CheckedInList.UseVisualStyleBackColor = True
        '
        'btn_GuestList
        '
        Me.btn_GuestList.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_GuestList.FlatAppearance.BorderSize = 0
        Me.btn_GuestList.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Orange
        Me.btn_GuestList.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_GuestList.Location = New System.Drawing.Point(330, 153)
        Me.btn_GuestList.Name = "btn_GuestList"
        Me.btn_GuestList.Size = New System.Drawing.Size(233, 52)
        Me.btn_GuestList.TabIndex = 9
        Me.btn_GuestList.Text = "GUEST LIST"
        Me.btn_GuestList.UseVisualStyleBackColor = True
        '
        'btn_CheckedoutList
        '
        Me.btn_CheckedoutList.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_CheckedoutList.FlatAppearance.BorderSize = 0
        Me.btn_CheckedoutList.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Orange
        Me.btn_CheckedoutList.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_CheckedoutList.Location = New System.Drawing.Point(13, 153)
        Me.btn_CheckedoutList.Name = "btn_CheckedoutList"
        Me.btn_CheckedoutList.Size = New System.Drawing.Size(233, 52)
        Me.btn_CheckedoutList.TabIndex = 7
        Me.btn_CheckedoutList.Text = "CHECKED OUT LIST"
        Me.btn_CheckedoutList.UseVisualStyleBackColor = True
        '
        'btn_ReservedList
        '
        Me.btn_ReservedList.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_ReservedList.FlatAppearance.BorderSize = 0
        Me.btn_ReservedList.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Orange
        Me.btn_ReservedList.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_ReservedList.Location = New System.Drawing.Point(13, 256)
        Me.btn_ReservedList.Name = "btn_ReservedList"
        Me.btn_ReservedList.Size = New System.Drawing.Size(233, 52)
        Me.btn_ReservedList.TabIndex = 8
        Me.btn_ReservedList.Text = "RESERVED LIST"
        Me.btn_ReservedList.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.White
        Me.GroupBox1.BackgroundImage = CType(resources.GetObject("GroupBox1.BackgroundImage"), System.Drawing.Image)
        Me.GroupBox1.Controls.Add(Me.Panel3)
        Me.GroupBox1.Controls.Add(Me.btn_ReserveManagement)
        Me.GroupBox1.Controls.Add(Me.btn_AddRoom)
        Me.GroupBox1.Controls.Add(Me.btn_ManageDiscount)
        Me.GroupBox1.Controls.Add(Me.btn_CheckOut)
        Me.GroupBox1.Controls.Add(Me.btn_CheckIn)
        Me.GroupBox1.Controls.Add(Me.btn_AddGuest)
        Me.GroupBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.ForeColor = System.Drawing.Color.Maroon
        Me.GroupBox1.Location = New System.Drawing.Point(36, 319)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(579, 384)
        Me.GroupBox1.TabIndex = 12
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "TRANSACTIONS"
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.Orange
        Me.Panel3.Location = New System.Drawing.Point(0, 349)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(579, 35)
        Me.Panel3.TabIndex = 6
        '
        'btn_ReserveManagement
        '
        Me.btn_ReserveManagement.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_ReserveManagement.FlatAppearance.BorderSize = 0
        Me.btn_ReserveManagement.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Orange
        Me.btn_ReserveManagement.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_ReserveManagement.Location = New System.Drawing.Point(329, 256)
        Me.btn_ReserveManagement.Name = "btn_ReserveManagement"
        Me.btn_ReserveManagement.Size = New System.Drawing.Size(233, 52)
        Me.btn_ReserveManagement.TabIndex = 5
        Me.btn_ReserveManagement.Text = "RESERVE MANAGEMENT"
        Me.btn_ReserveManagement.UseVisualStyleBackColor = True
        '
        'btn_AddRoom
        '
        Me.btn_AddRoom.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_AddRoom.FlatAppearance.BorderSize = 0
        Me.btn_AddRoom.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Orange
        Me.btn_AddRoom.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_AddRoom.Location = New System.Drawing.Point(329, 50)
        Me.btn_AddRoom.Name = "btn_AddRoom"
        Me.btn_AddRoom.Size = New System.Drawing.Size(233, 52)
        Me.btn_AddRoom.TabIndex = 4
        Me.btn_AddRoom.Text = "ADD ROOM"
        Me.btn_AddRoom.UseVisualStyleBackColor = True
        '
        'btn_ManageDiscount
        '
        Me.btn_ManageDiscount.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_ManageDiscount.FlatAppearance.BorderSize = 0
        Me.btn_ManageDiscount.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Orange
        Me.btn_ManageDiscount.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_ManageDiscount.Location = New System.Drawing.Point(329, 153)
        Me.btn_ManageDiscount.Name = "btn_ManageDiscount"
        Me.btn_ManageDiscount.Size = New System.Drawing.Size(233, 52)
        Me.btn_ManageDiscount.TabIndex = 3
        Me.btn_ManageDiscount.Text = "MANAGE ROOM DISCOUNT"
        Me.btn_ManageDiscount.UseVisualStyleBackColor = True
        '
        'btn_CheckOut
        '
        Me.btn_CheckOut.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_CheckOut.FlatAppearance.BorderSize = 0
        Me.btn_CheckOut.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Orange
        Me.btn_CheckOut.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_CheckOut.Location = New System.Drawing.Point(12, 256)
        Me.btn_CheckOut.Name = "btn_CheckOut"
        Me.btn_CheckOut.Size = New System.Drawing.Size(233, 52)
        Me.btn_CheckOut.TabIndex = 2
        Me.btn_CheckOut.Text = "CHECK OUT"
        Me.btn_CheckOut.UseVisualStyleBackColor = True
        '
        'btn_CheckIn
        '
        Me.btn_CheckIn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_CheckIn.FlatAppearance.BorderSize = 0
        Me.btn_CheckIn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Orange
        Me.btn_CheckIn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_CheckIn.Location = New System.Drawing.Point(12, 153)
        Me.btn_CheckIn.Name = "btn_CheckIn"
        Me.btn_CheckIn.Size = New System.Drawing.Size(233, 52)
        Me.btn_CheckIn.TabIndex = 1
        Me.btn_CheckIn.Text = "CHECK IN"
        Me.btn_CheckIn.UseVisualStyleBackColor = True
        '
        'btn_AddGuest
        '
        Me.btn_AddGuest.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_AddGuest.FlatAppearance.BorderSize = 0
        Me.btn_AddGuest.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red
        Me.btn_AddGuest.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Orange
        Me.btn_AddGuest.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_AddGuest.Location = New System.Drawing.Point(12, 50)
        Me.btn_AddGuest.Name = "btn_AddGuest"
        Me.btn_AddGuest.Size = New System.Drawing.Size(233, 52)
        Me.btn_AddGuest.TabIndex = 0
        Me.btn_AddGuest.Text = "ADD GUEST"
        Me.btn_AddGuest.UseVisualStyleBackColor = True
        '
        'PictureBox2
        '
        Me.PictureBox2.Image = CType(resources.GetObject("PictureBox2.Image"), System.Drawing.Image)
        Me.PictureBox2.Location = New System.Drawing.Point(36, 58)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(224, 218)
        Me.PictureBox2.TabIndex = 15
        Me.PictureBox2.TabStop = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.White
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Black
        Me.Label1.Location = New System.Drawing.Point(1103, 5)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(106, 18)
        Me.Label1.TabIndex = 17
        Me.Label1.Text = "USERNAME | "
        '
        'lblUsername
        '
        Me.lblUsername.AutoSize = True
        Me.lblUsername.BackColor = System.Drawing.Color.White
        Me.lblUsername.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblUsername.ForeColor = System.Drawing.Color.Maroon
        Me.lblUsername.Location = New System.Drawing.Point(1202, 5)
        Me.lblUsername.Name = "lblUsername"
        Me.lblUsername.Size = New System.Drawing.Size(20, 18)
        Me.lblUsername.TabIndex = 19
        Me.lblUsername.Text = "..."
        '
        'PictureBox3
        '
        Me.PictureBox3.Image = CType(resources.GetObject("PictureBox3.Image"), System.Drawing.Image)
        Me.PictureBox3.Location = New System.Drawing.Point(1103, 58)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(224, 218)
        Me.PictureBox3.TabIndex = 20
        Me.PictureBox3.TabStop = False
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.White
        Me.Panel1.Controls.Add(Me.Panel2)
        Me.Panel1.Location = New System.Drawing.Point(259, 58)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(847, 218)
        Me.Panel1.TabIndex = 21
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.Orange
        Me.Panel2.Location = New System.Drawing.Point(0, 110)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(855, 108)
        Me.Panel2.TabIndex = 22
        '
        'MainMenu
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.ClientSize = New System.Drawing.Size(1370, 749)
        Me.Controls.Add(Me.lblUsername)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.PictureBox3)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.MenuStrip)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.StatusStrip)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.IsMdiContainer = True
        Me.Name = "MainMenu"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MenuStrip.ResumeLayout(False)
        Me.MenuStrip.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ToolTip As System.Windows.Forms.ToolTip
    Friend WithEvents StatusStrip As System.Windows.Forms.StatusStrip
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents MenuStrip As System.Windows.Forms.MenuStrip
    Friend WithEvents file_Option As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents help_Option As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents developer_Option As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents logout_Option As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator12 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents reports_Option As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents backup_Option As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents btn_RoomsList As System.Windows.Forms.Button
    Friend WithEvents btn_CheckedInList As System.Windows.Forms.Button
    Friend WithEvents btn_GuestList As System.Windows.Forms.Button
    Friend WithEvents btn_CheckedoutList As System.Windows.Forms.Button
    Friend WithEvents btn_ReservedList As System.Windows.Forms.Button
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents btn_ReserveManagement As System.Windows.Forms.Button
    Friend WithEvents btn_AddRoom As System.Windows.Forms.Button
    Friend WithEvents btn_ManageDiscount As System.Windows.Forms.Button
    Friend WithEvents btn_CheckOut As System.Windows.Forms.Button
    Friend WithEvents btn_CheckIn As System.Windows.Forms.Button
    Friend WithEvents btn_AddGuest As System.Windows.Forms.Button
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents lblUsername As System.Windows.Forms.Label
    Friend WithEvents PictureBox3 As System.Windows.Forms.PictureBox
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents Panel3 As System.Windows.Forms.Panel

End Class
