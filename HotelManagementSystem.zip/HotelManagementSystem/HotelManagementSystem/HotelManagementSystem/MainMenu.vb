﻿Imports System.Windows.Forms

Public Class MainMenu

    Private Sub ShowNewForm(ByVal sender As Object, ByVal e As EventArgs)
        ' Create a new instance of the child form.
        Dim ChildForm As New System.Windows.Forms.Form
        ' Make it a child of this MDI form before showing it.
        ChildForm.MdiParent = Me

        m_ChildFormNumber += 1
        ChildForm.Text = "Window " & m_ChildFormNumber

        ChildForm.Show()
    End Sub

    Private Sub OpenFile(ByVal sender As Object, ByVal e As EventArgs)
        Dim OpenFileDialog As New OpenFileDialog
        OpenFileDialog.InitialDirectory = My.Computer.FileSystem.SpecialDirectories.MyDocuments
        OpenFileDialog.Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*"
        If (OpenFileDialog.ShowDialog(Me) = System.Windows.Forms.DialogResult.OK) Then
            Dim FileName As String = OpenFileDialog.FileName
            ' TODO: Add code here to open the file.
        End If
    End Sub

    Private Sub SaveAsToolStripMenuItem_Click(ByVal sender As Object, ByVal e As EventArgs)
        Dim SaveFileDialog As New SaveFileDialog
        SaveFileDialog.InitialDirectory = My.Computer.FileSystem.SpecialDirectories.MyDocuments
        SaveFileDialog.Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*"

        If (SaveFileDialog.ShowDialog(Me) = System.Windows.Forms.DialogResult.OK) Then
            Dim FileName As String = SaveFileDialog.FileName
            ' TODO: Add code here to save the current contents of the form to a file.
        End If
    End Sub


    Private Sub ExitToolsStripMenuItem_Click(ByVal sender As Object, ByVal e As EventArgs)
        Me.Close()
    End Sub

    Private Sub CutToolStripMenuItem_Click(ByVal sender As Object, ByVal e As EventArgs)
        ' Use My.Computer.Clipboard to insert the selected text or images into the clipboard
    End Sub

    Private Sub CopyToolStripMenuItem_Click(ByVal sender As Object, ByVal e As EventArgs)
        ' Use My.Computer.Clipboard to insert the selected text or images into the clipboard
    End Sub

    Private Sub PasteToolStripMenuItem_Click(ByVal sender As Object, ByVal e As EventArgs)
        'Use My.Computer.Clipboard.GetText() or My.Computer.Clipboard.GetData to retrieve information from the clipboard.
    End Sub

    Private Sub CascadeToolStripMenuItem_Click(ByVal sender As Object, ByVal e As EventArgs)
        Me.LayoutMdi(MdiLayout.Cascade)
    End Sub

    Private Sub TileVerticalToolStripMenuItem_Click(ByVal sender As Object, ByVal e As EventArgs)
        Me.LayoutMdi(MdiLayout.TileVertical)
    End Sub

    Private Sub TileHorizontalToolStripMenuItem_Click(ByVal sender As Object, ByVal e As EventArgs)
        Me.LayoutMdi(MdiLayout.TileHorizontal)
    End Sub

    Private Sub ArrangeIconsToolStripMenuItem_Click(ByVal sender As Object, ByVal e As EventArgs)
        Me.LayoutMdi(MdiLayout.ArrangeIcons)
    End Sub

    Private Sub CloseAllToolStripMenuItem_Click(ByVal sender As Object, ByVal e As EventArgs)
        ' Close all child forms of the parent.
        For Each ChildForm As Form In Me.MdiChildren
            ChildForm.Close()
        Next
    End Sub

    Private m_ChildFormNumber As Integer

    Private Sub developer_Option_Click(sender As Object, e As EventArgs) Handles developer_Option.Click
        Call developer.ShowDialog()
    End Sub

    Private Sub help_Option_Click(sender As Object, e As EventArgs) Handles help_Option.Click
        Call help.ShowDialog()
    End Sub

    Private Sub logout_Option_Click(sender As Object, e As EventArgs) Handles logout_Option.Click
        End
    End Sub

    Private Sub btn_AddGuest_Click(sender As Object, e As EventArgs) Handles btn_AddGuest.Click
        Call addGuest.ShowDialog()
    End Sub

    Private Sub MainMenu_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        lblUsername.Text = login.txt_Username.Text.ToUpper

    End Sub

    Private Sub btn_AddRoom_Click(sender As Object, e As EventArgs) Handles btn_AddRoom.Click
        Call addRoom.ShowDialog()
    End Sub

    Private Sub btn_ManageDiscount_Click(sender As Object, e As EventArgs) Handles btn_ManageDiscount.Click
        Call discount.ShowDialog()
    End Sub

    Private Sub btn_CheckIn_Click(sender As Object, e As EventArgs) Handles btn_CheckIn.Click
        Call checkIn.ShowDialog()
    End Sub

    Private Sub btn_GuestList_Click(sender As Object, e As EventArgs) Handles btn_GuestList.Click
        Call guestList.ShowDialog()
    End Sub

    Private Sub btn_RoomsList_Click(sender As Object, e As EventArgs) Handles btn_RoomsList.Click
        Call roomsList.ShowDialog()
    End Sub

    Private Sub btn_CheckOut_Click(sender As Object, e As EventArgs) Handles btn_CheckOut.Click
        Call checkOut.ShowDialog()
    End Sub

    Private Sub btn_CheckedInList_Click(sender As Object, e As EventArgs) Handles btn_CheckedInList.Click
        Call checkedInList.ShowDialog()
    End Sub

    Private Sub btn_CheckedoutList_Click(sender As Object, e As EventArgs) Handles btn_CheckedoutList.Click
        Call checkOutList.ShowDialog()
    End Sub

    Private Sub btn_ReserveManagement_Click(sender As Object, e As EventArgs) Handles btn_ReserveManagement.Click
        Call reserve.ShowDialog()
    End Sub

    Private Sub btn_ReservedList_Click(sender As Object, e As EventArgs) Handles btn_ReservedList.Click
        Call reserveList.ShowDialog()
    End Sub

    Private Sub backup_Option_Click(sender As Object, e As EventArgs) Handles backup_Option.Click
        Call backup.ShowDialog()
    End Sub

    Private Sub MainMenu_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing
        Dim exit_app As String = MessageBox.Show("Exit application", "Notification", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        If exit_app = vbNo Then
            e.Cancel = True
        Else
            End
        End If
    End Sub
End Class
