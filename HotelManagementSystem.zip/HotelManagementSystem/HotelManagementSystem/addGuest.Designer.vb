﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class addGuest
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(addGuest))
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.btn_Save = New System.Windows.Forms.Button()
        Me.btn_Cancel = New System.Windows.Forms.Button()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.lbl_guestHeader = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txt_LName = New System.Windows.Forms.TextBox()
        Me.txt_FName = New System.Windows.Forms.TextBox()
        Me.txt_MName = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txt_Email = New System.Windows.Forms.TextBox()
        Me.txt_Number = New System.Windows.Forms.TextBox()
        Me.cbo_Gender = New System.Windows.Forms.ComboBox()
        Me.txt_Address = New System.Windows.Forms.RichTextBox()
        Me.txt_NId = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.Panel2.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.White
        Me.Panel2.Controls.Add(Me.btn_Save)
        Me.Panel2.Controls.Add(Me.btn_Cancel)
        resources.ApplyResources(Me.Panel2, "Panel2")
        Me.Panel2.Name = "Panel2"
        '
        'btn_Save
        '
        Me.btn_Save.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btn_Save.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_Save.FlatAppearance.BorderSize = 0
        Me.btn_Save.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Orange
        resources.ApplyResources(Me.btn_Save, "btn_Save")
        Me.btn_Save.ForeColor = System.Drawing.Color.White
        Me.btn_Save.Name = "btn_Save"
        Me.btn_Save.UseVisualStyleBackColor = False
        '
        'btn_Cancel
        '
        Me.btn_Cancel.BackColor = System.Drawing.Color.Maroon
        Me.btn_Cancel.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_Cancel.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btn_Cancel.FlatAppearance.BorderSize = 0
        Me.btn_Cancel.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Orange
        resources.ApplyResources(Me.btn_Cancel, "btn_Cancel")
        Me.btn_Cancel.ForeColor = System.Drawing.Color.White
        Me.btn_Cancel.Name = "btn_Cancel"
        Me.btn_Cancel.UseVisualStyleBackColor = False
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.Orange
        resources.ApplyResources(Me.Panel1, "Panel1")
        Me.Panel1.Name = "Panel1"
        '
        'lbl_guestHeader
        '
        resources.ApplyResources(Me.lbl_guestHeader, "lbl_guestHeader")
        Me.lbl_guestHeader.BackColor = System.Drawing.Color.Orange
        Me.lbl_guestHeader.ForeColor = System.Drawing.Color.White
        Me.lbl_guestHeader.Name = "lbl_guestHeader"
        '
        'Label6
        '
        resources.ApplyResources(Me.Label6, "Label6")
        Me.Label6.BackColor = System.Drawing.Color.White
        Me.Label6.Name = "Label6"
        '
        'txt_LName
        '
        Me.txt_LName.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        resources.ApplyResources(Me.txt_LName, "txt_LName")
        Me.txt_LName.Name = "txt_LName"
        '
        'txt_FName
        '
        Me.txt_FName.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        resources.ApplyResources(Me.txt_FName, "txt_FName")
        Me.txt_FName.Name = "txt_FName"
        '
        'txt_MName
        '
        Me.txt_MName.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        resources.ApplyResources(Me.txt_MName, "txt_MName")
        Me.txt_MName.Name = "txt_MName"
        '
        'Label1
        '
        resources.ApplyResources(Me.Label1, "Label1")
        Me.Label1.BackColor = System.Drawing.Color.White
        Me.Label1.Name = "Label1"
        '
        'Label4
        '
        resources.ApplyResources(Me.Label4, "Label4")
        Me.Label4.BackColor = System.Drawing.Color.White
        Me.Label4.Name = "Label4"
        '
        'Label2
        '
        resources.ApplyResources(Me.Label2, "Label2")
        Me.Label2.BackColor = System.Drawing.Color.White
        Me.Label2.Name = "Label2"
        '
        'Label5
        '
        resources.ApplyResources(Me.Label5, "Label5")
        Me.Label5.BackColor = System.Drawing.Color.White
        Me.Label5.Name = "Label5"
        '
        'Label3
        '
        resources.ApplyResources(Me.Label3, "Label3")
        Me.Label3.BackColor = System.Drawing.Color.White
        Me.Label3.Name = "Label3"
        '
        'Label7
        '
        resources.ApplyResources(Me.Label7, "Label7")
        Me.Label7.BackColor = System.Drawing.Color.White
        Me.Label7.Name = "Label7"
        '
        'txt_Email
        '
        resources.ApplyResources(Me.txt_Email, "txt_Email")
        Me.txt_Email.Name = "txt_Email"
        '
        'txt_Number
        '
        Me.txt_Number.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txt_Number.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        resources.ApplyResources(Me.txt_Number, "txt_Number")
        Me.txt_Number.Name = "txt_Number"
        '
        'cbo_Gender
        '
        Me.cbo_Gender.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        resources.ApplyResources(Me.cbo_Gender, "cbo_Gender")
        Me.cbo_Gender.FormattingEnabled = True
        Me.cbo_Gender.Items.AddRange(New Object() {resources.GetString("cbo_Gender.Items"), resources.GetString("cbo_Gender.Items1")})
        Me.cbo_Gender.Name = "cbo_Gender"
        '
        'txt_Address
        '
        resources.ApplyResources(Me.txt_Address, "txt_Address")
        Me.txt_Address.Name = "txt_Address"
        '
        'txt_NId
        '
        Me.txt_NId.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        resources.ApplyResources(Me.txt_NId, "txt_NId")
        Me.txt_NId.Name = "txt_NId"
        '
        'Label9
        '
        resources.ApplyResources(Me.Label9, "Label9")
        Me.Label9.BackColor = System.Drawing.Color.White
        Me.Label9.Name = "Label9"
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.White
        Me.Panel3.Controls.Add(Me.Label9)
        Me.Panel3.Controls.Add(Me.txt_NId)
        Me.Panel3.Controls.Add(Me.txt_Address)
        Me.Panel3.Controls.Add(Me.cbo_Gender)
        Me.Panel3.Controls.Add(Me.txt_Number)
        Me.Panel3.Controls.Add(Me.txt_Email)
        Me.Panel3.Controls.Add(Me.Label7)
        Me.Panel3.Controls.Add(Me.Label3)
        Me.Panel3.Controls.Add(Me.Label5)
        Me.Panel3.Controls.Add(Me.Label2)
        Me.Panel3.Controls.Add(Me.Label4)
        Me.Panel3.Controls.Add(Me.Label1)
        Me.Panel3.Controls.Add(Me.txt_MName)
        Me.Panel3.Controls.Add(Me.txt_FName)
        Me.Panel3.Controls.Add(Me.txt_LName)
        Me.Panel3.Controls.Add(Me.Label6)
        resources.ApplyResources(Me.Panel3, "Panel3")
        Me.Panel3.Name = "Panel3"
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.Color.White
        resources.ApplyResources(Me.Panel4, "Panel4")
        Me.Panel4.Name = "Panel4"
        '
        'addGuest
        '
        resources.ApplyResources(Me, "$this")
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.lbl_guestHeader)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.Panel4)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow
        Me.Name = "addGuest"
        Me.Panel2.ResumeLayout(False)
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents btn_Save As System.Windows.Forms.Button
    Friend WithEvents btn_Cancel As System.Windows.Forms.Button
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents lbl_guestHeader As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txt_LName As System.Windows.Forms.TextBox
    Friend WithEvents txt_FName As System.Windows.Forms.TextBox
    Friend WithEvents txt_MName As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents txt_Email As System.Windows.Forms.TextBox
    Friend WithEvents txt_Number As System.Windows.Forms.TextBox
    Friend WithEvents cbo_Gender As System.Windows.Forms.ComboBox
    Friend WithEvents txt_Address As System.Windows.Forms.RichTextBox
    Friend WithEvents txt_NId As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
End Class
