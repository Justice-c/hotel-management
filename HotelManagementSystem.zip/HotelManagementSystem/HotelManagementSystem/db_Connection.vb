﻿Imports System.Data.OleDb
Imports System.Text.RegularExpressions
Module db_Connection
    Public result As String
    Public cmd As New OleDbCommand
    Public da As New OleDbDataAdapter
    Public dt As New DataTable
    Public dr As OleDbDataReader
    Public con As OleDb.OleDbConnection = Myconnection()
    Public rs As New OleDbDataAdapter

    Public Function Myconnection() As OleDb.OleDbConnection
        Return New OleDb.OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & Application.StartupPath & "\HotelReservationDb.accdb")
    End Function

    Function SafeSqlLiteral(ByVal strValue, ByVal intLevel) As String
        If Not IsDBNull(strValue) Then
            If intLevel > 0 Then
                'Preventing SQL injection attacks
                strValue = Replace(strValue, "'", "''")
                strValue = Replace(strValue, "--", "")
                strValue = Replace(strValue, "[", "[[]")
                strValue = Replace(strValue, "%", "[%]")
            End If

            If intLevel > 1 Then
                Dim myArray As Array
                myArray = Split("xp_ ;update ;insert ;select ;drop ;alter ;create ;rename ;delete ;replace ", ";")
                Dim i, i2, intLenghtLeft As Integer
                For i = LBound(myArray) To UBound(myArray)
                    Dim rx As New Regex(myArray(i), RegexOptions.Compiled Or RegexOptions.IgnoreCase)
                    Dim matches As MatchCollection = rx.Matches(strValue)
                    i2 = 0
                    For Each match As Match In matches
                        Dim groups As GroupCollection = match.Groups
                        intLenghtLeft = groups.Item(0).Index + Len(myArray(i)) + i2
                        strValue = Left(strValue, intLenghtLeft - 1) & "&nbsp;" & Right(strValue, Len(strValue) - intLenghtLeft)
                        i2 += 5
                    Next
                Next
            End If
            Return strValue
        Else
            Return strValue
        End If
    End Function

    Public Sub save(ByVal sql As String)
        Try
            Call con.Close()
            Call con.Open()
            With cmd
                .CommandText = sql
                .Connection = con
            End With

            result = cmd.ExecuteNonQuery
            If result > 0 Then
                Call MessageBox.Show("Transation Successfully Done", "Notification", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Else
                Call MessageBox.Show("Database Connection Fail", "Notification", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message)
            addRoom.txtID.BackColor = Color.Red
            addGuest.txt_Number.BackColor = Color.Red
        Finally
            Call con.Close()
        End Try
    End Sub

    Public Function FindItem(ByVal LV As ListView, ByVal TextToFind As String) As Integer
        For i As Integer = 0 To LV.Items.Count - 1
            If Trim(LV.Items(i).Text) = Trim(TextToFind) Then
                Return (i)
            End If
            For subitem As Integer = 0 To LV.Items(i).SubItems.Count - 1
                If Trim(LV.Items(i).SubItems(subitem).Text) = Trim(TextToFind) Then
                    Return (i)
                End If
            Next
        Next
        Return -1
    End Function

    Public Function getReserved() As DataTable
        Dim dtReserved As New DataTable
        Using cmd As New OleDbCommand("SELECT * FROM tblTransaction WHERE Remarks = 'Reserve' ORDER BY TransID ASC;", con)
            Call con.Close()
            Call con.Open()
            Dim reader As OleDbDataReader = cmd.ExecuteReader
            Call dtReserved.Load(reader)
        End Using
        Return dtReserved
    End Function

    Public Function getUsers() As DataTable
        Dim dtReserved As New DataTable
        Using cmd As New OleDbCommand("SELECT * FROM tblUser ORDER BY ID ASC;", con)
            Call con.Close()
            Call con.Open()
            Dim reader As OleDbDataReader = cmd.ExecuteReader
            Call dtReserved.Load(reader)
        End Using
        Return dtReserved
    End Function
End Module
