﻿Imports System.Data.OleDb
Public Class checkOutList

    Private Sub checkOutList_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call con.Close()
        Call con.Open()
        Dim Dt As New DataTable("tblTransaction")
        rs = New OleDbDataAdapter("Select * from tblTransaction, tblGuest, tblDiscount, tblRoom WHERE tblTransaction.GuestID = tblGuest.ID AND tblTransaction.DiscountID = tblDiscount.ID AND tblTransaction.RoomNum = tblRoom.RoomNumber AND tblTransaction.Remarks = 'Checkout' AND tblTransaction.Status = 'Active'", con)
        Call rs.Fill(Dt)

        Dim indx As Integer
        Call lvlcheckOut.Items.Clear()
        For indx = 0 To Dt.Rows.Count - 1
            Dim lv As New ListViewItem
            Dim getdate As TimeSpan
            Dim days, rate As Integer
            Dim subtotal, total, advance As Double
            Dim discount As Double

            Dim value As Integer = Val(Dt.Rows(indx).Item("TransID"))

            lv.Text = value.ToString("0000")
            lv.SubItems.Add(Dt.Rows(indx).Item("GuestFName") & " " & Dt.Rows(indx).Item("GuestLName"))
            lv.SubItems.Add(Dt.Rows(indx).Item("RoomNum"))

            rate = Dt.Rows(indx).Item("RoomRate")

            lv.SubItems.Add(Dt.Rows(indx).Item("CheckInDate"))
            lv.SubItems.Add(Dt.Rows(indx).Item("CheckOutDate"))

            dtIn.Value = Dt.Rows(indx).Item("CheckOutDate")
            dtOut.Value = Dt.Rows(indx).Item("CheckInDate")

            getdate = dtIn.Value - dtOut.Value
            days = getdate.Days

            lv.SubItems.Add(days)
            lv.SubItems.Add(Dt.Rows(indx).Item("NoOfChild"))
            lv.SubItems.Add(Dt.Rows(indx).Item("NoOfAdult"))
            advance = Dt.Rows(indx).Item("AdvancePayment")
            lv.SubItems.Add((advance).ToString("N"))
            lv.SubItems.Add(Dt.Rows(indx).Item("DiscountType"))

            discount = Val(Dt.Rows(indx).Item("DiscountRate"))

            subtotal = (days * rate) - ((days * rate) * discount)
            total = (Val(subtotal) - Val(Dt.Rows(indx).Item("AdvancePayment"))).ToString("N")

            If Val(subtotal) > Val(Dt.Rows(indx).Item("AdvancePayment")) Then
                lv.SubItems.Add(Val(total).ToString("N"))
            Else
                lv.SubItems.Add("$ 0.00")
            End If

            Call lvlcheckOut.Items.Add(lv)
        Next
        Call rs.Dispose()
        Call con.Close()
    End Sub

    Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click
        lvlcheckOut.MultiSelect = False
        lvlcheckOut.FullRowSelect = True
        Dim checkInt As Integer = FindItem(lvlcheckOut, txt_Search.Text)
        If checkInt <> -1 Then
            lvlcheckOut.Items(checkInt).Selected = True
            Call lvlcheckOut.Focus()
        Else
            Call MessageBox.Show("Transaction ID Not Found", "Notification", MessageBoxButtons.OK, MessageBoxIcon.Information)
        End If
    End Sub
End Class