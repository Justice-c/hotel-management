﻿Imports System.Data.OleDb
Public Class checkedInList

    Private Sub checkedInList_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call load_Form()
    End Sub

    Private Sub load_Form()
        Call con.Close()
        Call con.Open()
        Dim Dt As New DataTable("tblTransaction")
        rs = New OleDbDataAdapter("Select * from tblTransaction, tblGuest, tblDiscount, tblRoom WHERE tblTransaction.GuestID = tblGuest.ID AND tblTransaction.DiscountID = tblDiscount.ID AND tblTransaction.RoomNum = tblRoom.RoomNumber AND tblTransaction.Remarks = 'Checkin' AND tblTransaction.Status = 'Active' ORDER BY TransID ASC;", con)
        Call rs.Fill(Dt)

        Dim indx As Integer
        Call lvlcheckin.Items.Clear()
        For indx = 0 To Dt.Rows.Count - 1
            Dim lv As New ListViewItem
            Dim getdate As TimeSpan
            Dim days, subtotal, total, rate As Integer
            Dim discount As Double

            Dim value As Integer = Val(Dt.Rows(indx).Item("TransID"))

            lv.Text = value.ToString("0000")
            lv.SubItems.Add(Dt.Rows(indx).Item("GuestFName") & " " & Dt.Rows(indx).Item("GuestLName"))
            lv.SubItems.Add(Dt.Rows(indx).Item("RoomNum"))

            rate = Dt.Rows(indx).Item("RoomRate")

            lv.SubItems.Add(Dt.Rows(indx).Item("CheckInDate"))
            lv.SubItems.Add(Dt.Rows(indx).Item("CheckOutDate"))

            dtIn.Value = Dt.Rows(indx).Item("CheckOutDate")
            dtOut.Value = Dt.Rows(indx).Item("CheckInDate")

            getdate = dtIn.Value - dtOut.Value
            days = getdate.Days

            lv.SubItems.Add(days)
            lv.SubItems.Add(Dt.Rows(indx).Item("NoOfChild"))
            lv.SubItems.Add(Dt.Rows(indx).Item("NoOfAdult"))
            lv.SubItems.Add(Dt.Rows(indx).Item("AdvancePayment"))
            lv.SubItems.Add(Dt.Rows(indx).Item("DiscountType"))

            discount = Val(Dt.Rows(indx).Item("DiscountRate"))

            subtotal = (days * rate) - ((days * rate) * discount)
            total = Val(subtotal) - Val(Dt.Rows(indx).Item("AdvancePayment"))

            If Val(subtotal) > Val(Dt.Rows(indx).Item("AdvancePayment")) Then
                lv.SubItems.Add(Val(total))
            Else
                lv.SubItems.Add("0")
            End If

            lvlcheckin.Items.Add(lv)
        Next
        Call rs.Dispose()
        Call con.Close()
    End Sub

    Private Sub CheckOutGuest()

        dtIn.Value = lvlcheckin.SelectedItems(0).SubItems(3).Text
        dtOut.Value = Now.Date
        Call con.Close()
        Call con.Open()
        Dim dt As New DataTable("tblTransaction")
        rs = New OleDbDataAdapter("Select * from tblTransaction, tblRoom, tblDiscount WHERE tblTransaction.RoomNum = tblRoom.RoomNumber AND tblTransaction.DiscountID = tblDiscount.ID", con)
        Call rs.Fill(dt)
        Dim indx As Integer
        For indx = 0 To dt.Rows.Count - 1
            Dim value As Double = Val(dt.Rows(indx).Item("TransID"))

            If lvlcheckin.SelectedItems(0).Text = value.ToString("0000") Then
                checkOut.txtTransID.Text = value.ToString("0000")
                checkOut.lblTransID.Text = dt.Rows(indx).Item("TransID")
                checkOut.lblGuestID.Text = dt.Rows(indx).Item("GuestID")

                Dim time As DateTime = DateTime.Now
                Dim format As String = "d/MM/yyyy"
                Dim getdate As TimeSpan

                If dtIn.Value = dtOut.Value Then
                    checkOut.txtCheckout.Text = Now.Date.AddDays(1D)
                    checkOut.txtDays.Text = "1"
                    Dim subtotal As Double = Val(checkOut.txtDays.Text) * Val(dt.Rows(indx).Item("RoomRate"))
                    subtotal = Val(subtotal) - Val((dt.Rows(indx).Item("DiscountRate")) * Val(subtotal))

                    If Val(subtotal) > Val(dt.Rows(indx).Item("AdvancePayment")) Then
                        Dim total As Double = Val(subtotal) - (dt.Rows(indx).Item("AdvancePayment"))

                        checkOut.txtSubTotal.Text = Val(subtotal).ToString("N")
                        checkOut.txtTotal.Text = Val(total).ToString("N")
                        checkOut.txtCash.Text = Val(total).ToString("N")
                        checkOut.txtChange.Text = "0.00"
                    Else
                        Dim total As Double = (dt.Rows(indx).Item("AdvancePayment")) - Val(subtotal)
                        Dim change As Double = Val(total) - (dt.Rows(indx).Item("AdvancePayment"))

                        checkOut.txtSubTotal.Text = Val(subtotal).ToString("N")
                        checkOut.txtTotal.Text = "0.00"
                        checkOut.txtCash.Text = "0.00"
                        checkOut.txtChange.Text = Val(total).ToString("N")
                    End If

                Else
                    checkOut.txtCheckout.Text = Now.Date

                    getdate = (dtOut.Value) - (dtIn.Value)
                    checkOut.txtDays.Text = getdate.Days

                    Dim subtotal As Double = Val(getdate.Days) * Val(dt.Rows(indx).Item("RoomRate"))
                    subtotal = Val(subtotal) - Val((dt.Rows(indx).Item("DiscountRate")) * Val(subtotal))

                    If Val(subtotal) > Val(dt.Rows(indx).Item("AdvancePayment")) Then
                        Dim total As Double = Val(subtotal) - (dt.Rows(indx).Item("AdvancePayment"))

                        checkOut.txtSubTotal.Text = Val(subtotal).ToString("N")
                        checkOut.txtTotal.Text = Val(total).ToString("N")
                        checkOut.txtCash.Text = Val(total).ToString("N")
                        checkOut.txtChange.Text = "0.00"
                    Else
                        Dim total As Double = (dt.Rows(indx).Item("AdvancePayment")) - Val(subtotal)
                        Dim change As Double = Val(total) - (dt.Rows(indx).Item("AdvancePayment"))

                        checkOut.txtSubTotal.Text = Val(subtotal).ToString("N")
                        checkOut.txtTotal.Text = "0.00"
                        checkOut.txtCash.Text = "0.00"
                        checkOut.txtChange.Text = Val(total).ToString("N")
                    End If
                End If

                Exit For

            End If
        Next
        Call rs.Dispose()
        Call con.Close()

        checkOut.txtTransID.Text = lvlcheckin.SelectedItems(0).Text
        checkOut.txtGuestName.Text = lvlcheckin.SelectedItems(0).SubItems(1).Text
        checkOut.txtRoomNumber.Text = lvlcheckin.SelectedItems(0).SubItems(2).Text
        checkOut.txtCheckin.Text = lvlcheckin.SelectedItems(0).SubItems(3).Text

        checkOut.txtCheckout.Text = lvlcheckin.SelectedItems(0).SubItems(4).Text
        checkOut.txtDays.Text = lvlcheckin.SelectedItems(0).SubItems(5).Text
        checkOut.txtChildren.Text = lvlcheckin.SelectedItems(0).SubItems(6).Text
        checkOut.txtAdult.Text = lvlcheckin.SelectedItems(0).SubItems(7).Text
        checkOut.txtAdvance.Text = Val(lvlcheckin.SelectedItems(0).SubItems(8).Text).ToString("N")
        checkOut.txtDiscountType.Text = lvlcheckin.SelectedItems(0).SubItems(9).Text

        Call Me.Close()
    End Sub

    Private Sub lvlcheckin_DoubleClick(sender As Object, e As EventArgs) Handles lvlcheckin.DoubleClick
        Call CheckOutGuest()
        Call Me.Close()
    End Sub

    Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click
        lvlcheckin.MultiSelect = False
        lvlcheckin.FullRowSelect = True
        Dim checkInt As Integer = FindItem(lvlcheckin, txt_Search.Text)
        If checkInt <> -1 Then
            lvlcheckin.Items(checkInt).Selected = True
            Call lvlcheckin.Focus()
        Else
            MessageBox.Show("Transaction ID Not Found", "Notification", MessageBoxButtons.OK, MessageBoxIcon.Information)
        End If
    End Sub
End Class