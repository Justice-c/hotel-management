﻿Imports System.Data.OleDb
Public Class addGuest

    Private Sub addGuest_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub saveGuest()
        Call con.Close()
        Call con.Open()
        If (txt_NId.Text = Nothing Or txt_FName.Text = Nothing Or txt_LName.Text = Nothing Or txt_Address.Text = Nothing Or txt_Number.Text = Nothing Or cbo_Gender.Text = Nothing) Then
            Call MessageBox.Show("Please Fill All Required Fields", "Notification", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        ElseIf (btn_Save.Text = "SAVE") Then
            If txt_MName.Text = Nothing Then
                txt_MName.Text = "NONE"
            End If
            Dim status As String = "Active"
            Dim remark As String = "Available"
            Call save("INSERT INTO  tblGuest(GuestNationalId, GuestFName, GuestMName, GuestLName, GuestAddress, GuestContactNumber, GuestGender, GuestEmail, Status, Remarks) VALUES ('" & txt_NId.Text &
                 "', '" & txt_FName.Text &
                 "', '" & txt_MName.Text &
                 "', '" & txt_LName.Text &
                 "', '" & txt_Address.Text &
                 "', '" & txt_Number.Text &
                 "', '" & cbo_Gender.Text &
                 "', '" & txt_Email.Text.ToUpper &
                 "', '" & status.ToUpper &
                 "', '" & remark.ToUpper & "')")

        ElseIf (btn_Save.Text = "UPDATE") Then
            Dim status As String = "Active"
            Call con.Open()
            Dim activate_room As New OleDbCommand("UPDATE tblGuest SET GuestNationalId= '" &
                                                  SafeSqlLiteral(txt_NId.Text.ToUpper, 2) & "',GuestFName = '" &
                                                  SafeSqlLiteral(txt_FName.Text.ToUpper, 2) & "',GuestMName = '" &
                                                  SafeSqlLiteral(txt_MName.Text.ToUpper, 2) & "',GuestLName = '" &
                                                  SafeSqlLiteral(txt_LName.Text.ToUpper, 2) & "',GuestAddress = '" &
                                                  SafeSqlLiteral(txt_Address.Text.ToUpper.ToUpper, 2) & "',GuestContactNumber = '" &
                                                  SafeSqlLiteral(txt_Number.Text.ToUpper, 2) & "',GuestGender = '" &
                                                  SafeSqlLiteral(cbo_Gender.Text.ToUpper, 2) & "',GuestEmail = '" &
                                                  SafeSqlLiteral(txt_Email.Text.ToUpper, 2) & "',Status = '" &
                                                  SafeSqlLiteral(status.ToUpper, 2) & "' WHERE ID = " & guestList.id_num & "", con)
            Call activate_room.ExecuteNonQuery()
            Call activate_room.Dispose()
            Call con.Close()
            btn_Save.Text = "SAVE"
            Call MessageBox.Show("Guest Successfully Updated", "Notification", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Call clear()
            Call Me.Close()
            Call con.Close()
            Call guestList.display_guest()
        End If
    End Sub

    Private Sub clear()
        txt_NId.Text = Nothing
        txt_FName.Text = Nothing
        txt_MName.Text = Nothing
        txt_LName.Text = Nothing
        txt_Address.Text = Nothing
        txt_Number.Text = Nothing
        cbo_Gender.Text = Nothing
        txt_Email.Text = Nothing
    End Sub

    Private Sub btn_Save_Click(sender As Object, e As EventArgs) Handles btn_Save.Click
        Call saveGuest()
    End Sub

    Private Sub btn_Cancel_Click(sender As Object, e As EventArgs) Handles btn_Cancel.Click
        Call clear()
        txt_Number.BackColor = Color.White
    End Sub

    Private Sub txt_Number_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txt_Number.KeyPress
        If (Not Char.IsControl(e.KeyChar) _
                     AndAlso (Not Char.IsDigit(e.KeyChar))) Then
            e.Handled = True
        End If
    End Sub

    Private Sub txt_FName_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txt_FName.KeyPress
        If (Not Char.IsControl(e.KeyChar) _
                     AndAlso (Not Char.IsLetter(e.KeyChar))) Then
            e.Handled = True
        End If
    End Sub

    Private Sub txt_MName_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txt_MName.KeyPress
        If (Not Char.IsControl(e.KeyChar) _
                     AndAlso (Not Char.IsLetter(e.KeyChar))) Then
            e.Handled = True
        End If
    End Sub

    Private Sub txt_LName_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txt_LName.KeyPress
        If (Not Char.IsControl(e.KeyChar) _
                     AndAlso (Not Char.IsLetter(e.KeyChar))) Then
            e.Handled = True
        End If
    End Sub

    Private Sub cbo_Gender_KeyPress(sender As Object, e As KeyPressEventArgs) Handles cbo_Gender.KeyPress
        If (Not Char.IsControl(e.KeyChar) _
                     AndAlso (Not Char.IsLetter(e.KeyChar))) Then
            e.Handled = True
        End If
    End Sub

    Private Sub txt_Address_KeyPress(sender As Object, e As KeyPressEventArgs)
        If (Not Char.IsControl(e.KeyChar) _
                     AndAlso (Not Char.IsLetterOrDigit(e.KeyChar))) Then
            e.Handled = True
        End If
    End Sub
End Class
