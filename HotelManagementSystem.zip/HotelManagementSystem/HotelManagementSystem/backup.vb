﻿Imports System.IO
Public Class backup

    Private Sub btn_Backup_Click(sender As Object, e As EventArgs) Handles btn_Backup.Click
        Try
            Dim fbd As New FolderBrowserDialog
            If fbd.ShowDialog() = Windows.Forms.DialogResult.OK Then
                File.Copy("HotelReservationDb.accdb", fbd.SelectedPath & "\HotelReservationDb.accdb")
                MessageBox.Show("Data Backup Successfully Done", "Notification", MessageBoxButtons.OK, MessageBoxIcon.Information)
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Notification", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
End Class