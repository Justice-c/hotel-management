﻿Imports System .Data .OleDb 
Public Class checkOut

    Private Sub checkOut_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub bttnSearchGuest_Click(sender As Object, e As EventArgs) Handles bttnSearchGuest.Click
        Call checkedInList.ShowDialog()
    End Sub

    Private Sub txtCash_TextChanged(sender As Object, e As EventArgs) Handles txtCash.TextChanged
        If Val(txtCash.Text) < Val(txtTotal.Text) Then
            txtChange.Text = "0.00"
        Else
            txtChange.Text = (Val(txtCash.Text) - Val(txtTotal.Text)).ToString("N")
        End If
    End Sub

    Private Sub bttnCheckout_Click(sender As Object, e As EventArgs) Handles bttnCheckout.Click
        If txtTransID.Text = Nothing Then
            Call MessageBox.Show("Please Select Transaction To Checkout", "Notification", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        Else
            If Val(txtCash.Text) < Val(txtTotal.Text) Then
                Call MessageBox.Show("Insufficient cash", "Notification", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Else
                Dim out As String = MessageBox.Show("Confirm Checkout", "Notification", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                If out = vbYes Then
                    Call con.Close()
                    Call con.Open()
                    Dim update_trans As New OleDbCommand("UPDATE tblTransaction SET Remarks = 'Checkout' WHERE TransID = " & lblTransID.Text & "", con)
                    Call update_trans.ExecuteNonQuery()

                    Dim update_guest As New OleDbCommand("UPDATE tblGuest SET Remarks = 'Available' WHERE ID = " & lblGuestID.Text & "", con)
                    Call update_guest.ExecuteNonQuery()

                    Dim update_room As New OleDbCommand("UPDATE tblRoom SET Status = 'Available' WHERE RoomNumber = " & txtRoomNumber.Text & "", con)
                    Call update_room.ExecuteNonQuery()
                    Call MessageBox.Show("Guest Checked out", "Notification", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                    Call con.Close()
                    Call clear()
                    Call Me.Close()
                End If
            End If
        End If
    End Sub

    Public Sub clear()
        txtTransID.Text = Nothing
        txtGuestName.Text = Nothing
        txtRoomNumber.Text = Nothing
        txtCheckin.Text = Nothing
        txtCheckout.Text = Nothing
        txtChildren.Text = Nothing
        txtAdult.Text = Nothing
        txtAdvance.Text = Nothing
        txtDiscountType.Text = Nothing
        txtTotal.Text = Nothing
        txtSubTotal.Text = Nothing
        txtDays.Text = Nothing
        txtCash.Text = Nothing
        txtChange.Text = Nothing
    End Sub

    Private Sub btn_Cancel_Click(sender As Object, e As EventArgs) Handles btn_Cancel.Click
        Call Me.Close()
        Call Me.Dispose()
    End Sub


End Class