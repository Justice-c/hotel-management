﻿Imports System.Data.OleDb
Public Class guestList
    Public id_num As Integer

    Private Sub guestList_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call display_guest()
    End Sub

    Public Sub display_guest()
        Call con.Close()
        Call con.Open()
        Dim Dt As New DataTable("tblGuest")
        Dim rs As OleDbDataAdapter

        rs = New OleDbDataAdapter("Select ID, GuestNationalId, GuestFName, GuestMName, GuestLName, GuestAddress, GuestContactNumber, GuestGender, GuestEmail, Status from tblGuest ORDER BY GuestNationalId ASC;", con)

        Call rs.Fill(Dt)
        Dim indx As Integer
        Call lvGuest.Items.Clear()
        For indx = 0 To Dt.Rows.Count - 1
            Dim lv As New ListViewItem
            lv.Text = Dt.Rows(indx).Item("ID")
            lv.SubItems.Add(Dt.Rows(indx).Item("GuestNationalId"))
            lv.SubItems.Add(Dt.Rows(indx).Item("GuestFName"))
            lv.SubItems.Add(Dt.Rows(indx).Item("GuestMName"))
            lv.SubItems.Add(Dt.Rows(indx).Item("GuestLName"))
            lv.SubItems.Add(Dt.Rows(indx).Item("GuestAddress"))
            lv.SubItems.Add(Dt.Rows(indx).Item("GuestContactNumber"))
            lv.SubItems.Add(Dt.Rows(indx).Item("GuestGender"))
            lv.SubItems.Add(Dt.Rows(indx).Item("GuestEmail"))
            lv.SubItems.Add(Dt.Rows(indx).Item("Status"))
            lvGuest.Items.Add(lv)
        Next
        Call rs.Dispose()
        Call con.Close()
    End Sub

    Private Sub select_Info()
        Dim a As String = MessageBox.Show("Confirm Update Guest", "Notification", MessageBoxButtons.YesNo, MessageBoxIcon.Information)
        If a = vbYes Then
            If lvGuest.SelectedItems(0).SubItems(2).Text = "NONE" Then
                id_num = lvGuest.SelectedItems(0).Text
                addGuest.txt_NId.Text = lvGuest.SelectedItems(0).SubItems(1).Text
                addGuest.txt_FName.Text = lvGuest.SelectedItems(0).SubItems(2).Text
                addGuest.txt_MName.Text = lvGuest.SelectedItems(0).SubItems(3).Text
                addGuest.txt_LName.Text = lvGuest.SelectedItems(0).SubItems(4).Text
                addGuest.txt_Address.Text = lvGuest.SelectedItems(0).SubItems(5).Text
                addGuest.txt_Number.Text = Val(lvGuest.SelectedItems(0).SubItems(6).Text)
                addGuest.cbo_Gender.Text = lvGuest.SelectedItems(0).SubItems(7).Text
                addGuest.txt_Email.Text = lvGuest.SelectedItems(0).SubItems(8).Text
                addGuest.btn_Save.Text = "UPDATE"
                Call addGuest.ShowDialog()
            Else
                id_num = lvGuest.SelectedItems(0).Text
                addGuest.txt_NId.Text = lvGuest.SelectedItems(0).SubItems(1).Text
                addGuest.txt_FName.Text = lvGuest.SelectedItems(0).SubItems(2).Text
                addGuest.txt_MName.Text = lvGuest.SelectedItems(0).SubItems(3).Text
                addGuest.txt_LName.Text = lvGuest.SelectedItems(0).SubItems(4).Text
                addGuest.txt_Address.Text = lvGuest.SelectedItems(0).SubItems(5).Text
                addGuest.txt_Number.Text = Val(lvGuest.SelectedItems(0).SubItems(6).Text)
                addGuest.cbo_Gender.Text = lvGuest.SelectedItems(0).SubItems(7).Text
                addGuest.txt_Email.Text = lvGuest.SelectedItems(0).SubItems(8).Text
                addGuest.btn_Save.Text = "UPDATE"
                Call addGuest.ShowDialog()
            End If

        Else
            Call display_guest()
            Call addGuest.Close()
        End If
    End Sub

    Private Sub lvGuest_DoubleClick(sender As Object, e As EventArgs) Handles lvGuest.DoubleClick
        Call select_Info()
    End Sub

    Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click
        lvGuest.MultiSelect = False
        lvGuest.FullRowSelect = True
        Dim checkInt As Integer = FindItem(lvGuest, txt_Search.Text)
        If checkInt <> -1 Then
            lvGuest.Items(checkInt).Selected = True
            Call lvGuest.Focus()
        Else
            MessageBox.Show("Transaction ID Not Found", "Notification", MessageBoxButtons.OK, MessageBoxIcon.Information)
        End If
    End Sub
End Class